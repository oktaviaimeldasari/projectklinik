import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestFonnte {
    public static void main(String[] args) {
        try {
            String token = "yUCeGmNJFPs4w5fridCp";
            String target = "088225231517";
            String message = "Test Fonnte API dari Kliniku";
            
            URL url = new URL("https://api.fonnte.com/send");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", token);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            
            String postData = "target=" + target + "&message=" + message;
            try (OutputStream os = conn.getOutputStream()) {
                os.write(postData.getBytes());
            }
            
            int responseCode = conn.getResponseCode();
            System.out.println("Response Code: " + responseCode);
            
            try (BufferedReader br = new BufferedReader(new InputStreamReader(
                    responseCode >= 400 ? conn.getErrorStream() : conn.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
