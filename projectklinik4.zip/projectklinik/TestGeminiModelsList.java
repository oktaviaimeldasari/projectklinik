import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestGeminiModelsList {
    public static void main(String[] args) {
        try {
            String apiKey = "AIzaSyCQ8JShflACwZ33yXYqglH9bHAa1EISxIU";
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models?key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();
            
            try (BufferedReader br = new BufferedReader(new InputStreamReader(
                    responseCode >= 400 ? conn.getErrorStream() : conn.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains("\"name\"")) {
                        System.out.println(line);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
