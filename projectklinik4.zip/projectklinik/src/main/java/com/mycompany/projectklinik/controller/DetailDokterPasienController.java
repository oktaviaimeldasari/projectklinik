package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class DetailDokterPasienController implements Initializable {

    @FXML private Label namaLabel;
    @FXML private Label seninLabel;
    @FXML private Label selasaLabel;
    @FXML private Label rabuLabel;
    @FXML private Label kamisLabel;
    @FXML private Label jumatLabel;
    @FXML private ImageView fotoDokter;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String nama = App.getSelectedDokterName();
        if (nama != null) {
            namaLabel.setText(nama);
            setFotoDokter(nama);
        }
        
        loadJadwalDariDb();
    }

    private void setFotoDokter(String nama) {
        String fotoFile = nama.toLowerCase().contains("andi") ? "dr_andi.jpg" : "dr_ayu.jpg";
        try {
            Image img = new Image(getClass().getResourceAsStream("/com/mycompany/projectklinik/" + fotoFile));
            fotoDokter.setImage(img);
        } catch (Exception e) {
            System.err.println("Gagal memuat foto dokter: " + e.getMessage());
        }
    }

    private void loadJadwalDariDb() {
        int dokterId = App.getSelectedDokterId();
        String sql = "SELECT DISTINCT DAYOFWEEK(tanggal) as hari_ke, waktu_mulai, waktu_selesai " +
                     "FROM jadwal_konsultasi " +
                     "WHERE id_dokter = ? AND status = 'Aktif'";

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, dokterId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int hariKe = rs.getInt("hari_ke");
                        String mulai = rs.getString("waktu_mulai");
                        String selesai = rs.getString("waktu_selesai");
                        
                        // Format ke HH.mm (contoh: 08.00)
                        if (mulai != null && mulai.length() >= 5) mulai = mulai.substring(0, 5).replace(':', '.');
                        if (selesai != null && selesai.length() >= 5) selesai = selesai.substring(0, 5).replace(':', '.');
                        
                        String formattedTime = ": " + mulai + " - " + selesai;
                        
                        switch (hariKe) {
                            case 2:
                                seninLabel.setText(formattedTime);
                                break;
                            case 3:
                                selasaLabel.setText(formattedTime);
                                break;
                            case 4:
                                rabuLabel.setText(formattedTime);
                                break;
                            case 5:
                                kamisLabel.setText(formattedTime);
                                break;
                            case 6:
                                jumatLabel.setText(formattedTime);
                                break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DaftarBerobatPasien");
    }

    @FXML
    private void booking() throws IOException {
        App.setRoot("PilihJadwalPasien");
    }
}
