package com.mycompany.projectklinik.service;

import com.google.gson.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.Base64;

public class GeminiKtpOCR {

    private static final String API_KEY = "AIzaSyCQ8JShflACwZ33yXYqglH9bHAa1EISxIU";

    public static String scanKtp(File imageFile) throws Exception {

        byte[] imageBytes = Files.readAllBytes(imageFile.toPath());
        String base64Image = Base64.getEncoder().encodeToString(imageBytes);

        String prompt =
        "Anda adalah OCR KTP Indonesia. " +
        "Baca seluruh data pada KTP dan kembalikan HANYA JSON berikut: " +
        "{ " +
        "\"nik\":\"\", " +
        "\"nama\":\"\", " +
        "\"tempat_lahir\":\"\", " +
        "\"tanggal_lahir\":\"\", " +
        "\"jenis_kelamin\":\"\", " +
        "\"alamat\":\"\", " +
        "\"rt_rw\":\"\", " +
        "\"kelurahan\":\"\", " +
        "\"kecamatan\":\"\", " +
        "\"agama\":\"\", " +
        "\"status_perkawinan\":\"\", " +
        "\"pekerjaan\":\"\" " +
        "} " +
        "Jangan berikan penjelasan lain.";

        JsonObject requestBody = new JsonObject();

        JsonArray contents = new JsonArray();

        JsonObject content = new JsonObject();
        JsonArray parts = new JsonArray();

        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", prompt);

        JsonObject imagePart = new JsonObject();

        JsonObject inlineData = new JsonObject();
        inlineData.addProperty("mimeType", "image/jpeg");
        inlineData.addProperty("data", base64Image);

        imagePart.add("inlineData", inlineData);

        parts.add(textPart);
        parts.add(imagePart);

        content.add("parts", parts);
        contents.add(content);

        requestBody.add("contents", contents);

        URL url = new URL(
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="
    + API_KEY);

        HttpURLConnection conn =
                (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty(
                "Content-Type",
                "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(requestBody.toString().getBytes());
        }

        StringBuilder response = new StringBuilder();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {

            String line;

            while ((line = br.readLine()) != null) {
                response.append(line);
            }
        }

        JsonObject json =
                JsonParser.parseString(response.toString())
                        .getAsJsonObject();

        return json
                .getAsJsonArray("candidates")
                .get(0)
                .getAsJsonObject()
                .getAsJsonObject("content")
                .getAsJsonArray("parts")
                .get(0)
                .getAsJsonObject()
                .get("text")
                .getAsString();
    }
}