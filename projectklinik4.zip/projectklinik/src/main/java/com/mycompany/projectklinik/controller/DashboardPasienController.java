package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;

public class DashboardPasienController implements Initializable {

    @FXML private Label namaLabel;
    @FXML private Label nomorAndaLabel;
    @FXML private Label dokterLabel;
    @FXML private Label jamLabel;
    @FXML private ImageView fotoDokter;
    @FXML private StackPane logoutModal;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            String sqlPasien = "SELECT nama_pasien, id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasien)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String nama = rs.getString("nama_pasien");
                        int idPasien = rs.getInt("id_pasien");
                        // Tampilkan nama pertama saja
                        String firstName = nama.split(" ")[0];
                        namaLabel.setText(firstName);
                        
                        loadAntreanHariIni(conn, idPasien);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAntreanHariIni(Connection conn, int idPasien) {
        String sql = "SELECT a.no_antrian, d.nama_dokter " +
                     "FROM antrian a " +
                     "JOIN dokter d ON a.id_dokter = d.id_dokter " +
                     "WHERE a.id_pasien = ? AND a.tanggal_antrian = CURDATE() " +
                     "ORDER BY a.id_antrian DESC LIMIT 1";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPasien);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int noAntrian = rs.getInt("no_antrian");
                    String namaDokter = rs.getString("nama_dokter");
                    
                    nomorAndaLabel.setText(String.format("%02d", noAntrian));
                    dokterLabel.setText(namaDokter);
                    jamLabel.setText("Sesuai Jadwal");
                    
                    // Set foto dokter
                    String fotoFile = namaDokter.toLowerCase().contains("andi") ? "dr_andi.jpg" : "dr_ayu.jpg";
                    try {
                        Image img = new Image(getClass().getResourceAsStream("/com/mycompany/projectklinik/" + fotoFile));
                        fotoDokter.setImage(img);
                    } catch (Exception e) {
                        System.err.println("Gagal memuat foto dokter: " + e.getMessage());
                    }
                } else {
                    nomorAndaLabel.setText("--");
                    dokterLabel.setText("-");
                    jamLabel.setText("-");
                    fotoDokter.setImage(null);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void daftarBerobat() throws IOException {
        App.setRoot("DaftarBerobatPasien");
    }

    @FXML
    private void bukaProfil() throws IOException {
        App.setRoot("ProfilPasien");
    }

    @FXML
    private void bukaRiwayat() throws IOException {
        App.setRoot("RiwayatRekamMedisList");
    }

    @FXML
    private void logout() throws IOException {
        logoutModal.setVisible(true);
        logoutModal.setManaged(true);
    }

    @FXML
    private void handleLogoutConfirmYes() throws IOException {
        logoutModal.setVisible(false);
        logoutModal.setManaged(false);
        App.setLoggedInUserId(0);
        App.setLoggedInUsername(null);
        App.setRoot("LoginPasien");
    }

    @FXML
    private void handleLogoutConfirmNo() {
        logoutModal.setVisible(false);
        logoutModal.setManaged(false);
    }
}
