package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;

public class RiwayatRekamMedisDetailController implements Initializable {

    @FXML private Label namaLabel;
    @FXML private Label antrianTglLabel;
    @FXML private TextArea diagnosisArea;
    @FXML private Label tagihanLabel;
    @FXML private Label statusTagihanLabel;
    
    @FXML private Button btnResep;
    @FXML private Button btnRujukan;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadDetail();
    }

    private void loadDetail() {
        int idRekamMedis = App.getSelectedRekamMedisId();
        int idAntrian = App.getSelectedAntrianId();
        String tanggal = App.getSelectedRekamMedisTanggal();
        int idPasien = 0;
        
        if (idRekamMedis == 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            // 1. Ambil data rekam medis & pasien & antrian
            String sqlRM = "SELECT rm.diagnosa, p.nama_pasien, p.id_pasien, a.no_antrian "
                         + "FROM rekam_medis rm "
                         + "JOIN pasien p ON rm.id_pasien = p.id_pasien "
                         + "JOIN pemeriksaan pem ON rm.id_pemeriksaan = pem.id_pemeriksaan "
                         + "JOIN antrian a ON pem.id_antrian = a.id_antrian "
                         + "WHERE rm.id_rekam_medis = ?";
            
            try (PreparedStatement ps = conn.prepareStatement(sqlRM)) {
                ps.setInt(1, idRekamMedis);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPasien = rs.getInt("id_pasien");
                        namaLabel.setText(rs.getString("nama_pasien"));
                        antrianTglLabel.setText("Tanggal kunjungan : " + tanggal + "\nNo. Antrian : " + rs.getInt("no_antrian"));
                        diagnosisArea.setText(rs.getString("diagnosa"));
                    }
                }
            }

            // 2. Ambil data tagihan
            String sqlTagihan = "SELECT total_tagihan, status FROM tagihan WHERE id_antrian = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlTagihan)) {
                ps.setInt(1, idAntrian);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        double total = rs.getDouble("total_tagihan");
                        String status = rs.getString("status");
                        
                        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
                        tagihanLabel.setText(formatRupiah.format(total));
                        
                        statusTagihanLabel.setText(status);
                        if (status.equalsIgnoreCase("Lunas")) {
                            statusTagihanLabel.setTextFill(Color.web("#27ae60")); // Hijau
                        } else {
                            statusTagihanLabel.setTextFill(Color.web("#ff0000")); // Merah
                        }
                    } else {
                        tagihanLabel.setText("Rp 0,00");
                        statusTagihanLabel.setText("Belum ada tagihan");
                        statusTagihanLabel.setTextFill(Color.web("#555555"));
                    }
                }
            }

            // 3. Cek apakah ada Resep Obat untuk id_pasien dan tanggal ini
            btnResep.setDisable(true);
            String sqlResep = "SELECT 1 FROM resep_obat WHERE id_pasien = ? AND tanggal = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlResep)) {
                ps.setInt(1, idPasien);
                ps.setString(2, tanggal);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        btnResep.setDisable(false);
                    }
                }
            }

            // 4. Cek apakah ada Surat Rujukan
            btnRujukan.setDisable(true);
            String sqlRujukan = "SELECT 1 FROM surat_rujukan WHERE id_rekam_medis = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlRujukan)) {
                ps.setInt(1, idRekamMedis);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        btnRujukan.setDisable(false);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void lihatResep() throws IOException {
        App.setRoot("RiwayatResepObat");
    }

    @FXML
    private void lihatRujukan() throws IOException {
        App.setRoot("RiwayatSuratRujukan");
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("RiwayatRekamMedisList");
    }
}
