package com.mycompany.projectklinik.service;

import okhttp3.*;
import java.io.IOException;

public class FonnteService {

    // TODO: Masukkan Token Fonnte Anda di sini
    private static final String FONNTE_TOKEN = "jucXsXEEthpnRuPMr5ut";

    public static void sendWhatsApp(String target, String message) {
        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("target", target)
                .add("message", message)
                .build();

        Request request = new Request.Builder()
                .url("https://api.fonnte.com/send")
                .post(formBody)
                .addHeader("Authorization", FONNTE_TOKEN)
                .build();

        // Gunakan enqueue agar tidak nge-freeze UI (Asynchronous)
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.err.println("Gagal mengirim WA ke " + target);
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    System.out.println("WA berhasil dikirim ke " + target);
                } else {
                    System.err.println("Gagal mengirim WA: " + response.body().string());
                }
                response.close();
            }
        });
    }
}
