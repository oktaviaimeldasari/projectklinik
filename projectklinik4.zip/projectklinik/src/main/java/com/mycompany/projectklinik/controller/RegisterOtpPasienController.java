package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.util.Duration;

public class RegisterOtpPasienController implements Initializable {

    @FXML private Label subtitleLabel;
    @FXML private TextField otp1;
    @FXML private TextField otp2;
    @FXML private TextField otp3;
    @FXML private TextField otp4;
    @FXML private Label errorLabel;
    @FXML private Label countdownLabel;

    private int secondsRemaining = 59;
    private Timeline timeline;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String phone = App.getRegHp();
        if (phone != null && phone.length() >= 4) {
            String obfuscated = phone.substring(0, 2) + "********" + phone.substring(phone.length() - 2);
            subtitleLabel.setText(obfuscated);
        }
        
        setupOtpField(otp1, otp2);
        setupOtpField(otp2, otp3);
        setupOtpField(otp3, otp4);
        setupOtpField(otp4, null);

        startTimer();
    }

    private void setupOtpField(TextField current, TextField next) {
        current.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                current.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (current.getText().length() > 1) {
                current.setText(current.getText().substring(0, 1));
            }
            if (current.getText().length() == 1 && next != null) {
                next.requestFocus();
            }
        });
    }

    private void startTimer() {
        if (timeline != null) timeline.stop();
        secondsRemaining = 59;
        updateTimerLabel();
        
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            secondsRemaining--;
            updateTimerLabel();
            if (secondsRemaining <= 0) {
                timeline.stop();
                countdownLabel.setText("Waktu OTP habis. Silakan kirim ulang.");
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void updateTimerLabel() {
        String secStr = secondsRemaining < 10 ? "0" + secondsRemaining : String.valueOf(secondsRemaining);
        countdownLabel.setText("Sisa waktu OTP: 00:" + secStr);
    }

    @FXML
    private void goBack() throws IOException {
        if (timeline != null) timeline.stop();
        App.setRoot("UploadKtpPasien");
    }

    @FXML
    private void masukanKode() {
        if (secondsRemaining <= 0) {
            showError("Waktu OTP sudah habis!");
            return;
        }

        String inputOtp = otp1.getText().trim() + otp2.getText().trim() + otp3.getText().trim() + otp4.getText().trim();
        if (inputOtp.length() < 4) {
            showError("Masukkan 4 digit kode OTP.");
            return;
        }
        
        String actualOtp = App.getResetOtp();
        if (inputOtp.equals(actualOtp)) {
            if (timeline != null) timeline.stop();
            simpanKeDatabase();
        } else {
            showError("Kode OTP salah!");
        }
    }

    private void simpanKeDatabase() {
        Connection conn = Database.getConnection();
        if (conn == null) {
            showError("Gagal terhubung ke database.");
            return;
        }

        try {
            conn.setAutoCommit(false); // Mulai transaksi

            // 1. Insert tabel user
            String sqlUser = "INSERT INTO user (username, password, nama_role, nama_admin, no_hp) VALUES (?, ?, 'pasien', '-', ?)";
            PreparedStatement psUser = conn.prepareStatement(sqlUser, Statement.RETURN_GENERATED_KEYS);
            psUser.setString(1, App.getRegHp());
            psUser.setString(2, App.getRegPassword());
            psUser.setString(3, App.getRegHp());
            psUser.executeUpdate();

            ResultSet rsUser = psUser.getGeneratedKeys();
            int idUser = 0;
            if (rsUser.next()) {
                idUser = rsUser.getInt(1);
            }

            String jsonResult = App.getOcrResult();
            String nik = "0000000000000000"; // Fallback default
            String alamat = ""; // Fallback default
            if (jsonResult != null && !jsonResult.isEmpty()) {
                try {
                    String cleanJson = jsonResult.replace("```json", "").replace("```", "").trim();
                    JsonObject jsonObject = JsonParser.parseString(cleanJson).getAsJsonObject();
                    if (jsonObject.has("nik")) {
                        nik = jsonObject.get("nik").getAsString();
                    }
                    if (jsonObject.has("alamat")) {
                        alamat = jsonObject.get("alamat").getAsString();
                    }
                } catch (Exception parseEx) {
                    System.err.println("Gagal parsing JSON OCR KTP");
                }
            }

            // 2. Insert tabel pasien
            String sqlPasien = "INSERT INTO pasien (id_user, nama_pasien, jenis_kelamin, no_hp, tanggal_lahir, alamat, nik) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psPasien = conn.prepareStatement(sqlPasien, Statement.RETURN_GENERATED_KEYS);
            psPasien.setInt(1, idUser);
            psPasien.setString(2, App.getRegNama());
            psPasien.setString(3, App.getRegGender());
            psPasien.setString(4, App.getRegHp());
            psPasien.setString(5, App.getRegTglLahir());
            psPasien.setString(6, alamat);
            psPasien.setString(7, nik);
            psPasien.executeUpdate();

            ResultSet rsPasien = psPasien.getGeneratedKeys();
            int idPasien = 0;
            if (rsPasien.next()) {
                idPasien = rsPasien.getInt(1);
            }

            // 3. Update tabel user untuk menyimpan id_pasien
            String sqlUpdateUser = "UPDATE user SET id_pasien = ? WHERE id_user = ?";
            PreparedStatement psUpdateUser = conn.prepareStatement(sqlUpdateUser);
            psUpdateUser.setInt(1, idPasien);
            psUpdateUser.setInt(2, idUser);
            psUpdateUser.executeUpdate();

            conn.commit(); // Selesai transaksi
            
            // Clear cache pendaftaran
            App.setRegNama(null);
            App.setRegTglLahir(null);
            App.setRegGender(null);
            App.setRegHp(null);
            App.setRegPassword(null);
            App.setRegKtpPath(null);
            App.setResetOtp(null);

            // Otomatis login menggunakan akun yang baru dibuat
            App.setLoggedInUserId(idUser);
            // Anda mungkin perlu menambahkan getter setter untuk getRegHp jika ingin menyimpan username
            
            App.setRoot("RegisterSuccessPasien");

        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception rollbackEx) {
                rollbackEx.printStackTrace();
            }
            showError("Terjadi kesalahan saat menyimpan data.");
        } finally {
            try {
                conn.setAutoCommit(true);
                conn.close();
            } catch (Exception closeEx) {
                closeEx.printStackTrace();
            }
        }
    }

    @FXML
    private void kirimUlangKode() {
        String dynamicOtp = String.format("%04d", new java.util.Random().nextInt(10000));
        String pesanWa = "Kliniku: Kode OTP Registrasi Anda yang baru adalah *" + dynamicOtp + "*.";
        com.mycompany.projectklinik.service.FonnteService.sendWhatsApp(App.getRegHp(), pesanWa);
        App.setResetOtp(dynamicOtp);
        System.out.println("OTP Baru WA dikirim ke " + App.getRegHp());
        errorLabel.setStyle("-fx-text-fill: green;");
        showError("OTP baru telah dikirim.");
        
        otp1.clear(); otp2.clear(); otp3.clear(); otp4.clear();
        otp1.requestFocus();
        startTimer();

        new java.util.Timer().schedule(
            new java.util.TimerTask() {
                @Override
                public void run() {
                    javafx.application.Platform.runLater(() -> {
                        errorLabel.setVisible(false);
                        errorLabel.setStyle("-fx-text-fill: RED;");
                    });
                }
            }, 3000
        );
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
