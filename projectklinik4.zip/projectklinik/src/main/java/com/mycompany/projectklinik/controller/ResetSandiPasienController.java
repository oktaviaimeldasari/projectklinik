package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ResetSandiPasienController {

    @FXML private PasswordField passField;
    @FXML private TextField passTextField;
    @FXML private Button passToggleBtn;

    @FXML private PasswordField confirmPassField;
    @FXML private TextField confirmPassTextField;
    @FXML private Button confirmPassToggleBtn;

    @FXML private Label errorLabel;

    private boolean isPassVisible = false;
    private boolean isConfirmPassVisible = false;

    @FXML
    private void goBack() throws IOException {
        App.setRoot("OtpPasien");
    }

    @FXML
    private void handleTogglePass() {
        if (isPassVisible) {
            passField.setText(passTextField.getText());
            passTextField.setVisible(false);
            passField.setVisible(true);
            passToggleBtn.setText("👁");
            isPassVisible = false;
        } else {
            passTextField.setText(passField.getText());
            passField.setVisible(false);
            passTextField.setVisible(true);
            passToggleBtn.setText("🔒");
            isPassVisible = true;
        }
    }

    @FXML
    private void handleToggleConfirmPass() {
        if (isConfirmPassVisible) {
            confirmPassField.setText(confirmPassTextField.getText());
            confirmPassTextField.setVisible(false);
            confirmPassField.setVisible(true);
            confirmPassToggleBtn.setText("👁");
            isConfirmPassVisible = false;
        } else {
            confirmPassTextField.setText(confirmPassField.getText());
            confirmPassField.setVisible(false);
            confirmPassTextField.setVisible(true);
            confirmPassToggleBtn.setText("🔒");
            isConfirmPassVisible = true;
        }
    }

    @FXML
    private void simpanSandi() {
        String pass = isPassVisible ? passTextField.getText() : passField.getText();
        String confirmPass = isConfirmPassVisible ? confirmPassTextField.getText() : confirmPassField.getText();

        if (pass.isEmpty() || confirmPass.isEmpty()) {
            showError("Password tidak boleh kosong!");
            return;
        }

        if (!pass.equals(confirmPass)) {
            showError("Konfirmasi password tidak cocok!");
            return;
        }

        String phone = App.getResetPhone();
        if (phone == null || phone.isEmpty()) {
            showError("Sesi tidak valid, kembali ke awal.");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showError("Database tidak terhubung!");
                return;
            }

            String sql = "UPDATE user SET password = ? WHERE username = ? AND nama_role = 'pasien'";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, pass);
                ps.setString(2, phone);
                
                int updated = ps.executeUpdate();
                if (updated > 0) {
                    System.out.println("Password untuk " + phone + " berhasil direset.");
                    
                    // Clear state
                    App.setResetPhone(null);
                    App.setResetOtp(null);
                    
                    App.setRoot("LoginPasien");
                } else {
                    showError("Gagal mereset password. User tidak ditemukan.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showError("Terjadi kesalahan sistem.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
