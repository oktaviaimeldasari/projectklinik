package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

public class ProfilPasienController implements Initializable {

    @FXML private TextField namaField;
    @FXML private TextField tglLahirField;
    @FXML private TextField hpField;
    @FXML private TextField genderField;
    @FXML private TextField alamatField;
    @FXML private TextField nikField;
    @FXML private Label messageLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadDataProfil();
    }

    private void loadDataProfil() {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showMessage("Gagal koneksi ke database", false);
                return;
            }

            String sql = "SELECT nama_pasien, tanggal_lahir, no_hp, jenis_kelamin, alamat,nik FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        namaField.setText(rs.getString("nama_pasien"));
                        tglLahirField.setText(rs.getString("tanggal_lahir"));
                        hpField.setText(rs.getString("no_hp"));
                        genderField.setText(rs.getString("jenis_kelamin"));
                        alamatField.setText(rs.getString("alamat"));
                        nikField.setText(rs.getString("nik")); // Database tidak menyimpan NIK lagi
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showMessage("Terjadi kesalahan saat memuat data", false);
        }
    }

    @FXML
    private void goToEdit() throws IOException {
        App.setRoot("EditProfilPasien");
    }

    private void showMessage(String msg, boolean isSuccess) {
        messageLabel.setText(msg);
        messageLabel.setTextFill(isSuccess ? Color.web("#27ae60") : Color.RED);
        messageLabel.setVisible(true);
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DashboardPasien");
    }
}
