package com.mycompany.projectklinik.controller;

import java.io.File;
import java.io.IOException;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.service.GeminiKtpOCR;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class UploadKtpPasienController {

    @FXML private Label iconLabel;
    @FXML private Label filenameLabel;
    @FXML private Label errorLabel;

    private String selectedFilePath = null;

    @FXML
    private void goBack() throws IOException {
        App.setRoot("RegisterPasien");
    }

    @FXML
    private void handleDragOver(DragEvent event) {
        if (event.getGestureSource() != event.getSource() && event.getDragboard().hasFiles()) {
            event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }
        event.consume();
    }

    @FXML
    private void handleDragDropped(DragEvent event) {
        var db = event.getDragboard();
        boolean success = false;
        if (db.hasFiles()) {
            File file = db.getFiles().get(0);
            String name = file.getName().toLowerCase();
            if (name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png")) {
                processSelectedFile(file);
                success = true;
            } else {
                showError("Format file harus JPG atau PNG!");
            }
        }
        event.setDropCompleted(success);
        event.consume();
    }

    private void processSelectedFile(File selectedFile) {
        long fileSizeInBytes = selectedFile.length();
        long fileSizeInMB = fileSizeInBytes / (1024 * 1024);
        
        if (fileSizeInMB > 2) {
            showError("Ukuran file tidak boleh lebih dari 2 MB!");
            return;
        }
        
        selectedFilePath = selectedFile.getAbsolutePath();
        filenameLabel.setText(selectedFile.getName());
        filenameLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #00a651; -fx-font-weight: bold;");
        iconLabel.setText("✅");
        errorLabel.setVisible(false);
    }

    @FXML
    private void handleUploadClick(MouseEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Pilih Foto KTP");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );

        Stage stage = (Stage) iconLabel.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            processSelectedFile(selectedFile);
        }
    }

    @FXML
    private void lanjut() throws IOException {

        if (selectedFilePath == null) {
            showError("Silakan upload foto KTP terlebih dahulu.");
            return;
        }

        try {

            File ktpFile = new File(selectedFilePath);

            String hasilOCR =
                    GeminiKtpOCR.scanKtp(ktpFile);

            System.out.println("HASIL OCR:");
            System.out.println(hasilOCR);

            App.setRegKtpPath(selectedFilePath);

            App.setOcrResult(hasilOCR);
            
            
            // con db
            // inset

            // Generate OTP dinamis
            String dynamicOtp = String.format("%04d", new java.util.Random().nextInt(10000));
            String pesanWa = "Kliniku: Kode OTP Registrasi Anda adalah *" + dynamicOtp + "*. Jangan bagikan kode ini kepada siapapun.";
            
            // Kirim pesan WA
            com.mycompany.projectklinik.service.FonnteService.sendWhatsApp(App.getRegHp(), pesanWa);

            App.setResetOtp(dynamicOtp);

            App.setRoot("RegisterOtpPasien");

        } catch (Exception e) {

            e.printStackTrace();

            showError("Gagal membaca data KTP.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
