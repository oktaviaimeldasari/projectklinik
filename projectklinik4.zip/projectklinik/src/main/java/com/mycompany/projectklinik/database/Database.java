package com.mycompany.projectklinik.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Database {

    private static final String BASE_URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_NAME = "klinikproject";
    private static final String URL = BASE_URL + DB_NAME;
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Koneksi ke database gagal: " + e.getMessage());
        }
        return connection;
    }

    public static void initializeDatabase() {
        // Step 1: Buat database jika belum ada
        try (Connection conn = DriverManager.getConnection(BASE_URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
            System.out.println("Database '" + DB_NAME + "' terverifikasi/dibuat.");
        } catch (SQLException e) {
            System.err.println("Gagal membuat database: " + e.getMessage());
            return;
        }

        // Step 2: Buat tabel relasional baru (8 tabel)
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Matikan sementara foreign key checks untuk menghindari dependency creation order issues
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");

            // 2. Tabel user (menggunakan ENUM untuk nama_role)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS user ("
                    + "id_user INT AUTO_INCREMENT PRIMARY KEY,"
                    + "username VARCHAR(50) UNIQUE NOT NULL,"
                    + "password VARCHAR(255) NOT NULL,"
                    + "nama_admin VARCHAR(30) NOT NULL DEFAULT '-',"
                    + "no_hp VARCHAR(15) NOT NULL DEFAULT '-',"
                    + "nama_role ENUM('admin', 'dokter', 'pasien') NOT NULL DEFAULT 'pasien',"
                    + "id_pasien INT,"
                    + "id_dokter INT"
                    + ")");
            
            // Pengaman: pastikan kolom id_pasien dan id_dokter ada di tabel user jika tabel sudah terlanjur dibuat sebelumnya
            try {
                stmt.executeUpdate("ALTER TABLE user ADD COLUMN id_pasien INT");
            } catch (Exception e) { /* Abaikan jika sudah ada */ }
            try {
                stmt.executeUpdate("ALTER TABLE user ADD COLUMN id_dokter INT");
            } catch (Exception e) { /* Abaikan jika sudah ada */ }

            // 4. Tabel dokter (spesialis dihapus, diganti no_hp)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS dokter ("
                    + "id_dokter INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_user INT,"
                    + "nama_dokter VARCHAR(100) NOT NULL,"
                    + "no_hp VARCHAR(20),"
                    + "no_izin_praktek VARCHAR(50),"
                    + "FOREIGN KEY (id_user) REFERENCES user(id_user)"
                    + ")");

            // 5. Tabel pasien (tambahkan jenis_kelamin, no_hp, tanggal_lahir, nik)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS pasien ("
                    + "id_pasien INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_user INT,"
                    + "nama_pasien VARCHAR(100) NOT NULL,"
                    + "jenis_kelamin VARCHAR(20),"
                    + "no_hp VARCHAR(20),"
                    + "tanggal_lahir DATE,"
                    + "alamat TEXT,"
                    + "nik VARCHAR(16) DEFAULT '0000000000000000',"
                    + "FOREIGN KEY (id_user) REFERENCES user(id_user)"
                    + ")");

            // Pengaman: pastikan kolom nik ada di tabel pasien
            try {
                stmt.executeUpdate("ALTER TABLE pasien ADD COLUMN nik VARCHAR(16) DEFAULT '0000000000000000'");
            } catch (Exception e) { /* Abaikan jika sudah ada */ }

            // 6. Tabel antrian (ditambahkan keluhan)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS antrian ("
                    + "id_antrian INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT,"
                    + "id_dokter INT,"
                    + "tanggal_antrian DATE NOT NULL,"
                    + "no_antrian INT NOT NULL,"
                    + "status VARCHAR(50) NOT NULL,"
                    + "keluhan TEXT,"
                    + "FOREIGN KEY (id_pasien) REFERENCES pasien(id_pasien),"
                    + "FOREIGN KEY (id_dokter) REFERENCES dokter(id_dokter)"
                    + ")");

            // 7. Tabel pemeriksaan
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS pemeriksaan ("
                    + "id_pemeriksaan INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_antrian INT,"
                    + "diagnosa TEXT,"
                    + "tindakan TEXT,"
                    + "tanggal_pemeriksaan DATETIME,"
                    + "FOREIGN KEY (id_antrian) REFERENCES antrian(id_antrian)"
                    + ")");

            // 8. Tabel rekam_medis (hapus terapi, tambahkan tindakan & catatan)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS rekam_medis ("
                    + "id_rekam_medis INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT,"
                    + "id_dokter INT,"
                    + "id_pemeriksaan INT,"
                    + "tanggal DATE NOT NULL,"
                    + "keluhan TEXT,"
                    + "diagnosa TEXT,"
                    + "tindakan TEXT,"
                    + "catatan TEXT,"
                    + "FOREIGN KEY (id_pasien) REFERENCES pasien(id_pasien),"
                    + "FOREIGN KEY (id_dokter) REFERENCES dokter(id_dokter),"
                    + "FOREIGN KEY (id_pemeriksaan) REFERENCES pemeriksaan(id_pemeriksaan)"
                    + ")");

            // 9. Tabel tagihan
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS tagihan ("
                    + "id_tagihan INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT,"
                    + "id_antrian INT,"
                    + "biaya_pemeriksaan DECIMAL(10,2) NOT NULL,"
                    + "biaya_admin DECIMAL(10,2) NOT NULL,"
                    + "total_tagihan DECIMAL(10,2) NOT NULL,"
                    + "status VARCHAR(50) NOT NULL,"
                    + "tanggal DATE NOT NULL,"
                    + "FOREIGN KEY (id_pasien) REFERENCES pasien(id_pasien),"
                    + "FOREIGN KEY (id_antrian) REFERENCES antrian(id_antrian)"
                    + ")");

            // 10. Tabel resep_obat
            try {
                boolean hasOldColumn = false;
                try (ResultSet rs = conn.getMetaData().getColumns(null, null, "resep_obat", "id_resep_obat")) {
                    if (rs.next()) {
                        hasOldColumn = true;
                    }
                }
                if (hasOldColumn) {
                    System.out.println("Mendeteksi tabel 'resep_obat' usang. Menghapus tabel...");
                    stmt.executeUpdate("DROP TABLE IF EXISTS resep_obat");
                }
            } catch (Exception e) {
                System.err.println("Gagal memeriksa tabel resep_obat usang: " + e.getMessage());
            }

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS resep_obat ("
                    + "id_resep INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT,"
                    + "id_dokter INT,"
                    + "obat TEXT NOT NULL,"
                    + "aturan_pakai VARCHAR(255),"
                    + "tanggal DATE NOT NULL,"
                    + "FOREIGN KEY (id_pasien) REFERENCES pasien(id_pasien),"
                    + "FOREIGN KEY (id_dokter) REFERENCES dokter(id_dokter)"
                    + ")");

            // 11. Tabel surat_rujukan
            try {
                boolean hasIdPasien = false;
                try (ResultSet rs = conn.getMetaData().getColumns(null, null, "surat_rujukan", "id_pasien")) {
                    if (rs.next()) {
                        hasIdPasien = true;
                    }
                }
                if (!hasIdPasien) {
                    System.out.println("Mendeteksi tabel 'surat_rujukan' usang. Menghapus tabel...");
                    stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");
                    stmt.executeUpdate("DROP TABLE IF EXISTS surat_rujukan");
                    stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");
                }
            } catch (Exception e) {
                System.err.println("Gagal memeriksa tabel surat_rujukan usang: " + e.getMessage());
            }

            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS surat_rujukan ("
                    + "id_rujukan INT AUTO_INCREMENT PRIMARY KEY,"
                    + "id_pasien INT,"
                    + "id_dokter INT,"
                    + "rs_tujuan VARCHAR(150) NOT NULL,"
                    + "diagnosa TEXT NOT NULL,"
                    + "tanggal DATE NOT NULL,"
                    + "FOREIGN KEY (id_pasien) REFERENCES pasien(id_pasien),"
                    + "FOREIGN KEY (id_dokter) REFERENCES dokter(id_dokter)"
                    + ")");

            // Aktifkan kembali foreign key checks
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");
            System.out.println("Semua tabel relasional berhasil dibuat/diverifikasi.");

            // Step 3: Seeding Data Default
            
            // Seed Users & Profiles (Admin, Dokter, Pasien)
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM user")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    // Seed Admin
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_admin, no_hp, nama_role) VALUES (1, 'admin', 'admin', 'Super Admin', '08123456789', 'admin')");

                    // Seed Dokter 1 (dr. Andi)
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_role) VALUES (2, 'dokter1', 'dokter', 'dokter')");
                    stmt.executeUpdate("INSERT INTO dokter (id_dokter, id_user, nama_dokter, no_hp, no_izin_praktek) VALUES (1, 2, 'dr. Andi', '08198765432', '123/IZIN-P/2025')");
                    stmt.executeUpdate("UPDATE user SET id_dokter = 1 WHERE id_user = 2");

                    // Seed Dokter 2 (dr. Ayu)
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_role) VALUES (6, 'dokter2', 'dokter', 'dokter')");
                    stmt.executeUpdate("INSERT INTO dokter (id_dokter, id_user, nama_dokter, no_hp, no_izin_praktek) VALUES (2, 6, 'dr. Ayu', '08123456789', '456/IZIN-P/2026')");
                    stmt.executeUpdate("UPDATE user SET id_dokter = 2 WHERE id_user = 6");


                    // Seed Pasien 1 (Minggu)
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_role) VALUES (3, 'pasien1', 'pasien', 'pasien')");
                    stmt.executeUpdate("INSERT INTO pasien (id_pasien, id_user, nama_pasien, jenis_kelamin, no_hp, tanggal_lahir, alamat) "
                            + "VALUES (1, 3, 'Minggu', 'Laki-laki', '081222333444', '1998-05-20', 'Jl. Sehat No. 1')");
                    stmt.executeUpdate("UPDATE user SET id_pasien = 1 WHERE id_user = 3");

                    // Seed Pasien 2 (Jono)
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_role) VALUES (4, 'pasien2', 'pasien', 'pasien')");
                    stmt.executeUpdate("INSERT INTO pasien (id_pasien, id_user, nama_pasien, jenis_kelamin, no_hp, tanggal_lahir, alamat) "
                            + "VALUES (2, 4, 'Jono', 'Laki-laki', '081555666777', '1999-06-21', 'Jl. Maju No. 2')");
                    stmt.executeUpdate("UPDATE user SET id_pasien = 2 WHERE id_user = 4");

                    // Seed Pasien 3 (Aisyah)
                    stmt.executeUpdate("INSERT INTO user (id_user, username, password, nama_role) VALUES (5, 'pasien3', 'pasien', 'pasien')");
                    stmt.executeUpdate("INSERT INTO pasien (id_pasien, id_user, nama_pasien, jenis_kelamin, no_hp, tanggal_lahir, alamat) "
                            + "VALUES (3, 5, 'Aisyah', 'Perempuan', '081777888999', '2001-08-22', 'Jl. Indah No. 3')");
                    stmt.executeUpdate("UPDATE user SET id_pasien = 3 WHERE id_user = 5");

                    System.out.println("Akun user & profil default berhasil dibuat.");
                }
            }

            // Seed Antrian
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM antrian")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO antrian (id_pasien, id_dokter, tanggal_antrian, no_antrian, status, keluhan) VALUES "
                            + "(1, 1, '2024-05-20', 1, 'Menunggu Verifikasi', 'Demam tinggi semenjak kemarin malam'),"
                            + "(2, 1, '2024-05-21', 2, 'Menunggu Verifikasi', 'Batuk kering disertai radang tenggorokan'),"
                            + "(3, 1, '2024-05-22', 3, 'Diverifikasi', 'Sakit kepala sebelah kiri (migrain)')");
                    System.out.println("Data antrean default berhasil ditambahkan.");
                }
            }

            // Seed Pemeriksaan
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM pemeriksaan")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO pemeriksaan (id_pemeriksaan, id_antrian, diagnosa, tindakan, tanggal_pemeriksaan) VALUES "
                            + "(1, 1, 'Common Cold', 'Pemberian obat flu dan vitamin C', '2024-05-20 09:30:00'),"
                            + "(2, 2, 'Bronchitis', 'Pemberian ekspektoran dan antibiotik', '2024-05-21 10:15:00'),"
                            + "(3, 3, 'Migraine', 'Pemberian parasetamol dan anjuran istirahat', '2024-05-22 11:00:00')");
                    System.out.println("Data pemeriksaan default berhasil ditambahkan.");
                }
            }

            // Seed Rekam Medis
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM rekam_medis")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO rekam_medis (id_rekam_medis, id_pasien, id_dokter, id_pemeriksaan, tanggal, keluhan, diagnosa, tindakan, catatan) VALUES "
                            + "(1, 1, 1, 1, '2024-05-20', 'Demam tinggi semenjak kemarin malam', 'Common Cold', 'Pemberian obat flu dan vitamin C', 'Pasien dianjurkan istirahat selama 3 hari.'),"
                            + "(2, 2, 1, 2, '2024-05-21', 'Batuk kering disertai radang tenggorokan', 'Bronchitis', 'Pemberian ekspektoran dan antibiotik', 'Kontrol kembali jika batuk berlanjut lebih dari 7 hari.'),"
                            + "(3, 3, 1, 3, '2024-05-22', 'Sakit kepala sebelah kiri (migrain)', 'Migraine', 'Pemberian parasetamol dan anjuran istirahat', 'Hindari paparan cahaya berlebih saat sakit kepala menyerang.')");
                    System.out.println("Data rekam medis default berhasil ditambahkan.");
                }
            }

            // Seed Tagihan
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM tagihan")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO tagihan (id_tagihan, id_pasien, id_antrian, biaya_pemeriksaan, biaya_admin, total_tagihan, status, tanggal) VALUES "
                            + "(1, 1, 1, 100000.00, 15000.00, 115000.00, 'Belum Lunas', '2024-05-20'),"
                            + "(2, 2, 2, 150000.00, 15000.00, 165000.00, 'Belum Lunas', '2024-05-21'),"
                            + "(3, 3, 3, 120000.00, 15000.00, 135000.00, 'Lunas', '2024-05-22')");
                    System.out.println("Data tagihan default berhasil ditambahkan.");
                }
            }

            // Seed Resep Obat
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM resep_obat")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO resep_obat (id_resep, id_pasien, id_dokter, obat, aturan_pakai, tanggal) VALUES "
                            + "(1, 1, 1, 'Paracetamol 500mg, Vitamin C 500mg', '3x1 tablet setelah makan', '2024-05-20'),"
                            + "(2, 2, 1, 'Amoxicillin 500mg, Bromhexine HCL', '3x1 tablet setelah makan (Amoxicillin harus dihabiskan)', '2024-05-21'),"
                            + "(3, 3, 1, 'Ibuprofen 400mg', '2x1 tablet setelah makan jika sakit kepala menyerang', '2024-05-22')");
                    System.out.println("Data resep obat default berhasil ditambahkan.");
                }
            }

            // Seed Surat Rujukan
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM surat_rujukan")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO surat_rujukan (id_rujukan, id_pasien, id_dokter, rs_tujuan, diagnosa, tanggal) VALUES "
                            + "(1, 1, 1, 'RS Umum Daerah', 'Penyakit dalam tingkat lanjut', '2023-11-05'),"
                            + "(2, 2, 1, 'RSUD KOTA DEPOK', 'Bronchitis Kronis - Evaluasi Spesialis Paru', '2024-05-21'),"
                            + "(3, 3, 1, 'RS ADVENT BANDUNG', 'Migraine Spesifik - Evaluasi Spesialis Saraf', '2024-05-22')");
                    System.out.println("Data rujukan default berhasil ditambahkan.");
                }
            }

        } catch (SQLException e) {
            System.err.println("Gagal inisialisasi tabel/data: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
