import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestGemini {
    public static void main(String[] args) {
        try {
            String apiKey = "AIzaSyCQ8JShflACwZ33yXYqglH9bHAa1EISxIU";
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash?key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();
            System.out.println("Response Code: " + responseCode);
            
            if (responseCode >= 400) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        System.out.println(line);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
