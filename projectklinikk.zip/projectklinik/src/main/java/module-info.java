module com.mycompany.projectklinik {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.mycompany.projectklinik to javafx.fxml;
    opens com.mycompany.projectklinik.controller to javafx.fxml;
    
    exports com.mycompany.projectklinik;
    exports com.mycompany.projectklinik.controller;
    exports com.mycompany.projectklinik.model;
    exports com.mycompany.projectklinik.database;
}
