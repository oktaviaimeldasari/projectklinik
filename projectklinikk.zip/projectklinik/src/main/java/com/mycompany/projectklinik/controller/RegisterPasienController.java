package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterPasienController {

    @FXML private TextField namaField;
    @FXML private DatePicker tglLahirField;
    @FXML private TextField hpField;
    @FXML private ComboBox<String> genderCombo;
    @FXML private PasswordField passField;
    @FXML private PasswordField confirmPassField;
    @FXML private Label errorLabel;

    @FXML
    private void goBack() throws IOException {
        App.setRoot("LoginPasien");
    }

    @FXML
    private void lanjut() {
        String nama = namaField.getText().trim();
        LocalDate tglLahir = tglLahirField.getValue();
        String hp = hpField.getText().trim();
        String gender = genderCombo.getValue();
        String pass = passField.getText();
        String confirmPass = confirmPassField.getText();

        if (nama.isEmpty() || tglLahir == null || hp.isEmpty() || gender == null || pass.isEmpty()) {
            showError("Semua field harus diisi!");
            return;
        }

        if (!pass.equals(confirmPass)) {
            showError("Konfirmasi password tidak cocok!");
            return;
        }

        // Cek apakah No HP sudah terdaftar
        try (Connection conn = Database.getConnection()) {
            if (conn != null) {
                String checkSql = "SELECT * FROM user WHERE username = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                    checkStmt.setString(1, hp);
                    try (ResultSet rs = checkStmt.executeQuery()) {
                        if (rs.next()) {
                            showError("No HP sudah terdaftar!");
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showError("Terjadi kesalahan sistem saat mengecek data.");
            return;
        }

        // Simpan state pendaftaran ke memori
        App.setRegNama(nama);
        App.setRegTglLahir(tglLahir.toString());
        App.setRegHp(hp);
        App.setRegGender(gender);
        App.setRegPassword(pass);

        // Pindah ke halaman Upload KTP
        try {
            App.setRoot("UploadKtpPasien");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
