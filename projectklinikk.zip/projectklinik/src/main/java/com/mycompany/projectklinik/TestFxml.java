package com.mycompany.projectklinik;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class TestFxml extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("Testing doctor.fxml...");
        try {
            FXMLLoader loader1 = new FXMLLoader(getClass().getResource("doctor.fxml"));
            loader1.load();
            System.out.println("doctor.fxml loaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Testing secondary.fxml...");
        try {
            FXMLLoader loader2 = new FXMLLoader(getClass().getResource("secondary.fxml"));
            loader2.load();
            System.out.println("secondary.fxml loaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        System.out.println("Testing primary.fxml...");
        try {
            FXMLLoader loader3 = new FXMLLoader(getClass().getResource("primary.fxml"));
            loader3.load();
            System.out.println("primary.fxml loaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
