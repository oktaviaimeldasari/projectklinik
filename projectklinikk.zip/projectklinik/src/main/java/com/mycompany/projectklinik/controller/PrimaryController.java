package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private Button togglePasswordButton;

    @FXML
    private Label errorLabel;

    private boolean isPasswordVisible = false;

    @FXML
    private void handleTogglePassword() {
        if (isPasswordVisible) {
            passwordField.setText(passwordTextField.getText());
            passwordTextField.setVisible(false);
            passwordField.setVisible(true);
            togglePasswordButton.setText("👁");
            isPasswordVisible = false;
        } else {
            passwordTextField.setText(passwordField.getText());
            passwordField.setVisible(false);
            passwordTextField.setVisible(true);
            togglePasswordButton.setText("🔒");
            isPasswordVisible = true;
        }
    }

    @FXML
    private void handleLogin() throws IOException {
        String username = usernameField.getText();
        String password = isPasswordVisible ? passwordTextField.getText() : passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Username dan password tidak boleh kosong!");
            errorLabel.setVisible(true);
            errorLabel.setManaged(true);
            return;
        }

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                errorLabel.setText("Gagal terhubung ke database!");
                errorLabel.setVisible(true);
                errorLabel.setManaged(true);
                return;
            }

            // Query dengan JOIN ke tabel roles dan LEFT JOIN ke dokter untuk mendapatkan nama_role dan profile dokter
            String sql = "SELECT u.*, r.nama_role, d.id_dokter, d.nama_dokter "
                       + "FROM user u "
                       + "JOIN roles r ON u.id_role = r.id_role "
                       + "LEFT JOIN dokter d ON u.id_dokter = d.id_dokter "
                       + "WHERE u.username = ? AND u.password = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String role = rs.getString("nama_role");
                        App.setLoggedInUserId(rs.getInt("id_user"));
                        App.setLoggedInUsername(rs.getString("username"));
                        
                        if ("Admin".equalsIgnoreCase(role)) {
                            // Admin -> Buka AdminDashboard (secondary)
                            App.setRoot("secondary");
                        } else if ("Dokter".equalsIgnoreCase(role)) {
                            App.setLoggedInDoctorId(rs.getInt("id_dokter"));
                            App.setLoggedInDoctorName(rs.getString("nama_dokter"));
                            // Dokter -> Buka DoctorDashboard
                            App.setRoot("doctor");
                        } else if ("Pasien".equalsIgnoreCase(role)) {
                            // Pasien -> Arahkan otomatis ke Tampilan Mobile Pasien
                            javafx.stage.Stage stage = (javafx.stage.Stage) usernameField.getScene().getWindow();
                            stage.setWidth(376);
                            stage.setHeight(839);
                            stage.centerOnScreen();
                            
                            App.setRoot("LoginPasien");
                        }
                    } else {
                        errorLabel.setText("Username atau password salah!");
                        errorLabel.setVisible(true);
                        errorLabel.setManaged(true);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            errorLabel.setText("Error: " + e.getMessage());
            errorLabel.setVisible(true);
            errorLabel.setManaged(true);
        }
    }

    @FXML
    private void switchToPatientMobile() throws IOException {
        javafx.stage.Stage stage = (javafx.stage.Stage) usernameField.getScene().getWindow();
        stage.setWidth(376);
        stage.setHeight(839);
        stage.centerOnScreen();
        App.setRoot("LoginPasien");
    }


    private void showInfoAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
