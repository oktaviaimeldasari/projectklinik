package com.mycompany.projectklinik.model;

import java.time.LocalDate;

public class Patient {
    private int idAntrian;
    private int no;
    private String namaPasien;
    private LocalDate tanggalDaftar;
    private String status;
    private String keluhan;
    private String noHp;
    private String alamat;
    private LocalDate tanggalLahir;
    private String jenisKelamin;

    public Patient(int idAntrian, int no, String namaPasien, LocalDate tanggalDaftar, String status, String keluhan, String noHp, String alamat, LocalDate tanggalLahir, String jenisKelamin) {
        this.idAntrian = idAntrian;
        this.no = no;
        this.namaPasien = namaPasien;
        this.tanggalDaftar = tanggalDaftar;
        this.status = status;
        this.keluhan = keluhan;
        this.noHp = noHp;
        this.alamat = alamat;
        this.tanggalLahir = tanggalLahir;
        this.jenisKelamin = jenisKelamin;
    }

    public int getIdAntrian() {
        return idAntrian;
    }

    public void setIdAntrian(int idAntrian) {
        this.idAntrian = idAntrian;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getNamaPasien() {
        return namaPasien;
    }

    public void setNamaPasien(String namaPasien) {
        this.namaPasien = namaPasien;
    }

    public LocalDate getTanggalDaftar() {
        return tanggalDaftar;
    }

    public void setTanggalDaftar(LocalDate tanggalDaftar) {
        this.tanggalDaftar = tanggalDaftar;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getKeluhan() {
        return keluhan;
    }

    public void setKeluhan(String keluhan) {
        this.keluhan = keluhan;
    }

    public String getNoHp() {
        return noHp;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public LocalDate getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(LocalDate tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    // New fields for medical records
    private String noRm;
    private String diagnosa;
    private String tindakan;
    private String catatan;

    public String getNoRm() {
        return noRm;
    }

    public void setNoRm(String noRm) {
        this.noRm = noRm;
    }

    public String getDiagnosa() {
        return diagnosa;
    }

    public void setDiagnosa(String diagnosa) {
        this.diagnosa = diagnosa;
    }

    public String getTindakan() {
        return tindakan;
    }

    public void setTindakan(String tindakan) {
        this.tindakan = tindakan;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }

    // New fields for billing/tagihan
    private int idTagihan;
    private String noTagihan;
    private double biayaPemeriksaan;
    private double biayaAdmin;
    private double totalTagihan;
    private String statusTagihan;

    public int getIdTagihan() {
        return idTagihan;
    }

    public void setIdTagihan(int idTagihan) {
        this.idTagihan = idTagihan;
    }

    public String getNoTagihan() {
        return noTagihan;
    }

    public void setNoTagihan(String noTagihan) {
        this.noTagihan = noTagihan;
    }

    public double getBiayaPemeriksaan() {
        return biayaPemeriksaan;
    }

    public void setBiayaPemeriksaan(double biayaPemeriksaan) {
        this.biayaPemeriksaan = biayaPemeriksaan;
    }

    public double getBiayaAdmin() {
        return biayaAdmin;
    }

    public void setBiayaAdmin(double biayaAdmin) {
        this.biayaAdmin = biayaAdmin;
    }

    public double getTotalTagihan() {
        return totalTagihan;
    }

    public void setTotalTagihan(double totalTagihan) {
        this.totalTagihan = totalTagihan;
    }

    public String getStatusTagihan() {
        return statusTagihan;
    }

    public void setStatusTagihan(String statusTagihan) {
        this.statusTagihan = statusTagihan;
    }

    // Prescription & Referral fields for Doctor Module
    private int idResep;
    private String obat;
    private String aturanPakai;
    private int idRujukan;
    private String rsTujuan;

    public int getIdResep() {
        return idResep;
    }

    public void setIdResep(int idResep) {
        this.idResep = idResep;
    }

    public String getObat() {
        return obat;
    }

    public void setObat(String obat) {
        this.obat = obat;
    }

    public String getAturanPakai() {
        return aturanPakai;
    }

    public void setAturanPakai(String aturanPakai) {
        this.aturanPakai = aturanPakai;
    }

    public int getIdRujukan() {
        return idRujukan;
    }

    public void setIdRujukan(int idRujukan) {
        this.idRujukan = idRujukan;
    }

    public String getRsTujuan() {
        return rsTujuan;
    }

    public void setRsTujuan(String rsTujuan) {
        this.rsTujuan = rsTujuan;
    }
}
