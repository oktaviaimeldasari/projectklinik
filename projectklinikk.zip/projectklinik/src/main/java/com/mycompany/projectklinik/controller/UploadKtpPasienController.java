package com.mycompany.projectklinik.controller;

import java.io.File;
import java.io.IOException;
import com.mycompany.projectklinik.App;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class UploadKtpPasienController {

    @FXML private Label iconLabel;
    @FXML private Label filenameLabel;
    @FXML private Label errorLabel;

    private String selectedFilePath = null;

    @FXML
    private void goBack() throws IOException {
        App.setRoot("RegisterPasien");
    }

    @FXML
    private void handleUploadClick(MouseEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Pilih Foto KTP");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );

        Stage stage = (Stage) iconLabel.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            long fileSizeInBytes = selectedFile.length();
            long fileSizeInMB = fileSizeInBytes / (1024 * 1024);
            
            if (fileSizeInMB > 2) {
                showError("Ukuran file tidak boleh lebih dari 2 MB!");
                return;
            }
            
            selectedFilePath = selectedFile.getAbsolutePath();
            filenameLabel.setText(selectedFile.getName());
            filenameLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #00a651; -fx-font-weight: bold;");
            iconLabel.setText("✅");
            errorLabel.setVisible(false);
        }
    }

    @FXML
    private void lanjut() throws IOException {
        if (selectedFilePath == null) {
            showError("Silakan upload foto KTP terlebih dahulu.");
            return;
        }

        App.setRegKtpPath(selectedFilePath);
        
        // Simulasikan pengiriman OTP sebelum pindah halaman
        String dummyOtp = "6872";
        App.setResetOtp(dummyOtp); // Reuse OTP state
        System.out.println("OTP Pendaftaran untuk " + App.getRegHp() + " adalah: " + dummyOtp);

        App.setRoot("RegisterOtpPasien");
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
