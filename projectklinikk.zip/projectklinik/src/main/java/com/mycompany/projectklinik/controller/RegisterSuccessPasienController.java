package com.mycompany.projectklinik.controller;

import java.io.IOException;
import com.mycompany.projectklinik.App;
import javafx.fxml.FXML;

public class RegisterSuccessPasienController {

    @FXML
    private void lanjutLogin() throws IOException {
        App.setRoot("DashboardPasien");
    }
}
