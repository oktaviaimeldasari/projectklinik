package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class RiwayatSuratRujukanController implements Initializable {

    @FXML private Label tanggalAtasLabel;
    @FXML private TextField namaField;
    @FXML private TextField tanggalField;
    @FXML private TextField alamatField;
    @FXML private TextField tujuanField;
    @FXML private TextField hasilField;
    @FXML private TextField catatanField;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadRujukan();
    }

    private void loadRujukan() {
        int idRekamMedis = App.getSelectedRekamMedisId();
        String tanggal = App.getSelectedRekamMedisTanggal();
        int userId = App.getLoggedInUserId();
        
        if (idRekamMedis == 0 || userId <= 0) return;
        
        tanggalAtasLabel.setText(tanggal);

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            int idPasien = 0;
            String sqlPasienId = "SELECT id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasienId)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPasien = rs.getInt("id_pasien");
                    }
                }
            }

            if (idPasien == 0) return;

            // Dapatkan data rujukan dan catatan dari rekam medis
            String sql = "SELECT r.rs_tujuan, r.diagnosa, r.tanggal, p.nama_pasien, p.alamat, rm.catatan "
                       + "FROM surat_rujukan r "
                       + "JOIN pasien p ON r.id_pasien = p.id_pasien "
                       + "LEFT JOIN rekam_medis rm ON r.id_pasien = rm.id_pasien AND r.tanggal = rm.tanggal "
                       + "WHERE r.id_pasien = ? AND r.tanggal = ? LIMIT 1";
            
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idPasien);
                ps.setString(2, tanggal);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        namaField.setText(rs.getString("nama_pasien"));
                        tanggalField.setText(rs.getString("tanggal"));
                        alamatField.setText(rs.getString("alamat"));
                        tujuanField.setText(rs.getString("rs_tujuan"));
                        hasilField.setText(rs.getString("diagnosa")); // diagnosa sbg hasil
                        
                        String catatan = rs.getString("catatan");
                        catatanField.setText(catatan != null ? catatan : "-");
                    } else {
                        tujuanField.setText("Tidak ada data rujukan");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("RiwayatRekamMedisDetail");
    }
}
