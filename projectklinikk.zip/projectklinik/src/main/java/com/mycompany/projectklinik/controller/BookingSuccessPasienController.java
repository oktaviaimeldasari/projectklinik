package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class BookingSuccessPasienController implements Initializable {

    @FXML private Label dokterLabel;
    @FXML private Label tanggalLabel;
    @FXML private Label jamLabel;
    @FXML private Label noAntrianLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String dokter = App.getSelectedDokterName();
        if (dokter != null) dokterLabel.setText(dokter);

        String tgl = App.getBookingTanggal();
        if (tgl != null) tanggalLabel.setText(tgl);

        String jam = App.getBookingJam();
        if (jam != null) jamLabel.setText(jam);

        int noAntrian = App.getBookingNoAntrian();
        if (noAntrian > 0) noAntrianLabel.setText(String.valueOf(noAntrian));
    }

    @FXML
    private void lihatDetail() throws IOException {
        // Kembali ke Dashboard
        App.setRoot("DashboardPasien");
    }
}
