package com.mycompany.projectklinik;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import com.mycompany.projectklinik.database.Database;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;

    // Session global variables
    private static int loggedInUserId;
    private static String loggedInUsername;
    private static int loggedInDoctorId;
    private static String loggedInDoctorName;

    public static int getLoggedInUserId() { return loggedInUserId; }
    public static void setLoggedInUserId(int id) { loggedInUserId = id; }

    public static String getLoggedInUsername() { return loggedInUsername; }
    public static void setLoggedInUsername(String username) { loggedInUsername = username; }

    public static int getLoggedInDoctorId() { return loggedInDoctorId; }
    public static void setLoggedInDoctorId(int id) { loggedInDoctorId = id; }

    public static String getLoggedInDoctorName() { return loggedInDoctorName; }
    public static void setLoggedInDoctorName(String name) { loggedInDoctorName = name; }

    // Reset Password State
    private static String resetPhone;
    private static String resetOtp;

    // Registration State
    private static String regNama;
    private static String regTglLahir;
    private static String regHp;
    private static String regGender;
    private static String regPassword;
    private static String regKtpPath;

    // Booking State
    private static int selectedDokterId;
    private static String selectedDokterName;
    private static String bookingTanggal;
    private static String bookingJam;
    private static int bookingNoAntrian;

    public static int getSelectedDokterId() { return selectedDokterId; }
    public static void setSelectedDokterId(int id) { selectedDokterId = id; }

    public static String getSelectedDokterName() { return selectedDokterName; }
    public static void setSelectedDokterName(String name) { selectedDokterName = name; }

    public static String getBookingTanggal() { return bookingTanggal; }
    public static void setBookingTanggal(String tgl) { bookingTanggal = tgl; }

    public static String getBookingJam() { return bookingJam; }
    public static void setBookingJam(String jam) { bookingJam = jam; }

    public static int getBookingNoAntrian() { return bookingNoAntrian; }
    public static void setBookingNoAntrian(int no) { bookingNoAntrian = no; }

    // Riwayat Rekam Medis State
    private static int selectedRekamMedisId;
    private static int selectedAntrianId;
    private static String selectedRekamMedisTanggal;

    public static int getSelectedRekamMedisId() { return selectedRekamMedisId; }
    public static void setSelectedRekamMedisId(int id) { selectedRekamMedisId = id; }

    public static int getSelectedAntrianId() { return selectedAntrianId; }
    public static void setSelectedAntrianId(int id) { selectedAntrianId = id; }

    public static String getSelectedRekamMedisTanggal() { return selectedRekamMedisTanggal; }
    public static void setSelectedRekamMedisTanggal(String tgl) { selectedRekamMedisTanggal = tgl; }

    public static String getResetPhone() { return resetPhone; }
    public static void setResetPhone(String phone) { resetPhone = phone; }

    public static String getResetOtp() { return resetOtp; }
    public static void setResetOtp(String otp) { resetOtp = otp; }

    // Registration Getters & Setters
    public static String getRegNama() { return regNama; }
    public static void setRegNama(String regNama) { App.regNama = regNama; }
    public static String getRegTglLahir() { return regTglLahir; }
    public static void setRegTglLahir(String regTglLahir) { App.regTglLahir = regTglLahir; }
    public static String getRegHp() { return regHp; }
    public static void setRegHp(String regHp) { App.regHp = regHp; }
    public static String getRegGender() { return regGender; }
    public static void setRegGender(String regGender) { App.regGender = regGender; }
    public static String getRegPassword() { return regPassword; }
    public static void setRegPassword(String regPassword) { App.regPassword = regPassword; }
    public static String getRegKtpPath() { return regKtpPath; }
    public static void setRegKtpPath(String regKtpPath) { App.regKtpPath = regKtpPath; }

    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("SplashPasien"), 360, 800);
        stage.setTitle("Klinikku - Modul Pasien");
        stage.setMaximized(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        // Inisialisasi database dan tabel sebelum aplikasi berjalan
        Database.initializeDatabase();
        
        launch();
    }

}