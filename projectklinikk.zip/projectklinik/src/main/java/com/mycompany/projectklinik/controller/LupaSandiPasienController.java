package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class LupaSandiPasienController {

    @FXML private TextField phoneField;
    @FXML private Label errorLabel;

    @FXML
    private void goBack() throws IOException {
        App.setRoot("LoginPasien");
    }

    @FXML
    private void kirimOtp() {
        String phone = phoneField.getText().trim();
        if (phone.isEmpty()) {
            showError("No HP tidak boleh kosong!");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showError("Database tidak terhubung!");
                return;
            }

            // Cek apakah nomor HP terdaftar sebagai pasien
            String sql = "SELECT * FROM user WHERE username = ? AND id_role = 3";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, phone);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        // Simulasi OTP
                        String dummyOtp = "5837";
                        System.out.println("OTP untuk " + phone + " adalah: " + dummyOtp);
                        
                        App.setResetPhone(phone);
                        App.setResetOtp(dummyOtp);
                        
                        App.setRoot("OtpPasien");
                    } else {
                        showError("No HP tidak terdaftar!");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showError("Terjadi kesalahan sistem.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
