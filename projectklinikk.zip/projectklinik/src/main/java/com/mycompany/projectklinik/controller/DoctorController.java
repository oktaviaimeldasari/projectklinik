package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import com.mycompany.projectklinik.model.Patient;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class DoctorController implements Initializable {

    // Main Content Views
    @FXML private VBox dashboardView;
    @FXML private VBox rekamMedisView;
    @FXML private VBox detailPeriksaView;
    @FXML private VBox resepObatView;
    @FXML private VBox rujukanView;

    // Sidebar buttons
    @FXML private Button btnMenuDashboard;
    @FXML private Button btnMenuRekamMedis;
    @FXML private Button btnMenuResepObat;
    @FXML private Button btnMenuRujukan;

    // Header labels
    @FXML private Label headerUserLabel;

    // Stats Labels
    @FXML private Label lblStatPasienHariIni;
    @FXML private Label lblStatRekamMedis;
    @FXML private Label lblStatResepObat;
    @FXML private Label lblStatRujukan;

    // Dashboard Table
    @FXML private TableView<Patient> tableView;
    @FXML private TableColumn<Patient, Integer> colNo;
    @FXML private TableColumn<Patient, String> colNama;
    @FXML private TableColumn<Patient, LocalDate> colTanggal;
    @FXML private TableColumn<Patient, String> colKeluhan;

    // Rekam Medis Table
    @FXML private TableView<Patient> rekamMedisTable;
    @FXML private TableColumn<Patient, Integer> colRmNo;
    @FXML private TableColumn<Patient, String> colRmNama;
    @FXML private TableColumn<Patient, LocalDate> colRmTanggal;
    @FXML private TableColumn<Patient, String> colRmKeluhan;
    @FXML private TableColumn<Patient, String> colRmStatus;
    @FXML private TableColumn<Patient, String> colRmAksi;
    @FXML private TextField rmSearchField;

    // Examination Form Fields
    @FXML private TextField pxNamaField;
    @FXML private TextField pxKeluhanField;
    @FXML private ComboBox<String> pxJenisKelaminComboBox;
    @FXML private DatePicker pxTanggalLahirPicker;
    @FXML private TextField pxNoHpField;
    @FXML private TextField pxAlamatField;
    
    // Tab Pemeriksaan elements
    @FXML private TextField inputRmDiagnosis;
    @FXML private TextField inputRmTindakan;
    @FXML private TextField inputRmCatatan;
    @FXML private TableView<RmItem> tabRmTable;
    @FXML private TableColumn<RmItem, Integer> colTabRmNo;
    @FXML private TableColumn<RmItem, String> colTabRmDiagnosis;
    @FXML private TableColumn<RmItem, String> colTabRmTindakan;
    @FXML private TableColumn<RmItem, String> colTabRmCatatan;

    // Status labels
    @FXML private Label lblResepStatus;
    @FXML private Label lblRujukanStatus;

    // Tab Resep elements
    @FXML private TextField tabResepObatField;
    @FXML private TextField tabResepDosisField;
    @FXML private TextField tabResepAturanField;
    @FXML private TextField tabResepJumlahField;
    @FXML private TableView<ResepItem> tabResepTable;
    @FXML private TableColumn<ResepItem, Integer> colTabResepNo;
    @FXML private TableColumn<ResepItem, String> colTabResepObat;
    @FXML private TableColumn<ResepItem, String> colTabResepDosis;
    @FXML private TableColumn<ResepItem, String> colTabResepAturan;
    @FXML private TableColumn<ResepItem, String> colTabResepJumlah;

    // Tab Rujukan elements
    @FXML private ComboBox<String> tabRujukanRsComboBox;
    @FXML private TextArea tabRujukanDiagnosaField;
    @FXML private TextArea tabRujukanCatatanField;

    public static class ResepItem {
        private int no;
        private String namaObat;
        private String dosis;
        private String aturanPakai;
        private String jumlah;

        public ResepItem(int no, String namaObat, String dosis, String aturanPakai, String jumlah) {
            this.no = no;
            this.namaObat = namaObat;
            this.dosis = dosis;
            this.aturanPakai = aturanPakai;
            this.jumlah = jumlah;
        }

        public int getNo() { return no; }
        public void setNo(int no) { this.no = no; }
        public String getNamaObat() { return namaObat; }
        public void setNamaObat(String namaObat) { this.namaObat = namaObat; }
        public String getDosis() { return dosis; }
        public void setDosis(String dosis) { this.dosis = dosis; }
        public String getAturanPakai() { return aturanPakai; }
        public void setAturanPakai(String aturanPakai) { this.aturanPakai = aturanPakai; }
        public String getJumlah() { return jumlah; }
        public void setJumlah(String jumlah) { this.jumlah = jumlah; }
    }

    private static class RujukanTemp {
        String rsTujuan;
        String diagnosa;
        String catatan;
    }

    public static class RmItem {
        private int no;
        private String diagnosis;
        private String tindakan;
        private String catatan;
        public RmItem(int no, String diagnosis, String tindakan, String catatan) {
            this.no = no;
            this.diagnosis = diagnosis;
            this.tindakan = tindakan;
            this.catatan = catatan;
        }
        public int getNo() { return no; }
        public void setNo(int no) { this.no = no; }
        public String getDiagnosis() { return diagnosis; }
        public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
        public String getTindakan() { return tindakan; }
        public void setTindakan(String tindakan) { this.tindakan = tindakan; }
        public String getCatatan() { return catatan; }
        public void setCatatan(String catatan) { this.catatan = catatan; }
    }

    private ObservableList<RmItem> tempRmList = FXCollections.observableArrayList();
    private ObservableList<ResepItem> tempResepList = FXCollections.observableArrayList();
    private RujukanTemp tempRujukan = null;

    // Resep Obat Fields
    @FXML private TableView<Patient> resepTable;
    @FXML private TableColumn<Patient, Integer> colResepNo;
    @FXML private TableColumn<Patient, String> colResepPasien;
    @FXML private TableColumn<Patient, String> colResepObat;
    @FXML private TableColumn<Patient, LocalDate> colResepTanggal;
    @FXML private TextField resepSearchField;
    @FXML private ComboBox<Patient> resepPasienComboBox;
    @FXML private TextArea resepObatArea;
    @FXML private TextField resepAturanField;

    // Surat Rujukan Fields
    @FXML private TableView<Patient> rujukanTable;
    @FXML private TableColumn<Patient, Integer> colRujukanNo;
    @FXML private TableColumn<Patient, String> colRujukanPasien;
    @FXML private TableColumn<Patient, String> colRujukanRs;
    @FXML private TableColumn<Patient, LocalDate> colRujukanTanggal;
    @FXML private TextField rujukanSearchField;
    @FXML private ComboBox<Patient> rujukanPasienComboBox;
    @FXML private ComboBox<String> rujukanRsComboBox;
    @FXML private TextArea rujukanDiagnosaArea;

    // Detail Resep Modal Overlays
    @FXML private StackPane resepDetailModalOverlay;
    @FXML private Label detailResepPasienLabel;
    @FXML private TableView<ResepItem> detailResepTable;
    @FXML private TableColumn<ResepItem, Integer> colDetailResepNo;
    @FXML private TableColumn<ResepItem, String> colDetailResepObat;
    @FXML private TableColumn<ResepItem, String> colDetailResepDosis;
    @FXML private TableColumn<ResepItem, String> colDetailResepAturan;
    @FXML private TableColumn<ResepItem, String> colDetailResepJumlah;
    @FXML private Label detailResepTteDokterLabel;
    @FXML private Label detailResepSipLabel;

    // Detail Rujukan Modal Overlays
    @FXML private StackPane rujukanDetailModalOverlay;
    @FXML private Label detailRujukanPasienLabel;
    @FXML private Label detailRujukanRsLabel;
    @FXML private Label detailRujukanTanggalLabel;
    @FXML private TextArea detailRujukanDiagnosaArea;
    @FXML private Label detailRujukanTteDokterLabel;
    @FXML private Label detailRujukanSipLabel;

    // Overlays
    @FXML private StackPane logoutOverlay;
    @FXML private StackPane loadingOverlay;
    @FXML private StackPane successOverlay;

    // Internal Data Lists
    private ObservableList<Patient> dashboardList = FXCollections.observableArrayList();
    private ObservableList<Patient> queueList = FXCollections.observableArrayList();
    private ObservableList<Patient> resepList = FXCollections.observableArrayList();
    private ObservableList<Patient> rujukanList = FXCollections.observableArrayList();
    private ObservableList<Patient> allPatientsList = FXCollections.observableArrayList();

    private Patient selectedPatientForPemeriksaan;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Set header profile name
        String docName = App.getLoggedInDoctorName();
        headerUserLabel.setText((docName != null && !docName.isEmpty() ? docName : "dr. Andi") + " 👤");

        // Enable auto-resize constrained resize policy for all tables
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        rekamMedisTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        resepTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        rujukanTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Adjust 'No.' columns to be small and compact
        configureNoColumn(colNo);
        configureNoColumn(colRmNo);
        configureNoColumn(colResepNo);
        configureNoColumn(colRujukanNo);
        if (colTabRmNo != null) {
            colTabRmNo.setText("No.");
            colTabRmNo.setMaxWidth(70);
            colTabRmNo.setMinWidth(50);
            colTabRmNo.setPrefWidth(60);
        }

        // Setup PropertyValueFactories
        // 1. Dashboard Table
        colNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
        colKeluhan.setCellValueFactory(new PropertyValueFactory<>("keluhan"));

        // 2. Rekam Medis (Queue) Table
        colRmNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colRmNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colRmTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
        colRmKeluhan.setCellValueFactory(new PropertyValueFactory<>("keluhan"));
        colRmStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        
        colRmAksi.setCellFactory(column -> new TableCell<Patient, String>() {
            private final Button btnPeriksa = new Button("Periksa");
            private final Button btnLihat = new Button("Lihat Detail");
            private final StackPane pane = new StackPane(btnPeriksa, btnLihat);
            {
                btnPeriksa.getStyleClass().add("btn-action-verify");
                btnPeriksa.setOnAction(e -> {
                    Patient patient = getTableView().getItems().get(getIndex());
                    handlePeriksaPasien(patient);
                });
                
                btnLihat.getStyleClass().add("btn-action-view");
                btnLihat.setOnAction(e -> {
                    Patient patient = getTableView().getItems().get(getIndex());
                    handleViewRekamMedisDetail(patient);
                });
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Patient p = getTableView().getItems().get(getIndex());
                    if ("Diverifikasi".equalsIgnoreCase(p.getStatus())) {
                        btnPeriksa.setVisible(true);
                        btnPeriksa.setManaged(true);
                        btnLihat.setVisible(false);
                        btnLihat.setManaged(false);
                    } else if ("Selesai".equalsIgnoreCase(p.getStatus())) {
                        btnPeriksa.setVisible(false);
                        btnPeriksa.setManaged(false);
                        btnLihat.setVisible(true);
                        btnLihat.setManaged(true);
                    } else {
                        btnPeriksa.setVisible(false);
                        btnPeriksa.setManaged(false);
                        btnLihat.setVisible(false);
                        btnLihat.setManaged(false);
                    }
                    setGraphic(pane);
                }
            }
        });

        // 3. Resep Table
        colResepNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colResepPasien.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colResepObat.setCellValueFactory(new PropertyValueFactory<>("obat"));
        colResepTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));

        // 4. Rujukan Table
        colRujukanNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colRujukanPasien.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colRujukanRs.setCellValueFactory(new PropertyValueFactory<>("rsTujuan"));
        colRujukanTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));

        // Setup Patient ComboBox Cell Factories
        setupPatientComboBox(resepPasienComboBox);
        setupPatientComboBox(rujukanPasienComboBox);

        // Bind filter listeners
        rmSearchField.textProperty().addListener((obs, oldVal, newVal) -> filterRekamMedisData());
        resepSearchField.textProperty().addListener((obs, oldVal, newVal) -> filterResepData());
        rujukanSearchField.textProperty().addListener((obs, oldVal, newVal) -> filterRujukanData());

        // Setup Tab Pemeriksaan (RM) Table
        if (tabRmTable != null) {
            tabRmTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
            colTabRmNo.setCellValueFactory(new PropertyValueFactory<>("no"));
            colTabRmDiagnosis.setCellValueFactory(new PropertyValueFactory<>("diagnosis"));
            colTabRmTindakan.setCellValueFactory(new PropertyValueFactory<>("tindakan"));
            colTabRmCatatan.setCellValueFactory(new PropertyValueFactory<>("catatan"));
            tabRmTable.setItems(tempRmList);
        }

        // Setup Tab Resep Table
        tabResepTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        colTabResepNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colTabResepObat.setCellValueFactory(new PropertyValueFactory<>("namaObat"));
        colTabResepDosis.setCellValueFactory(new PropertyValueFactory<>("dosis"));
        colTabResepAturan.setCellValueFactory(new PropertyValueFactory<>("aturanPakai"));
        colTabResepJumlah.setCellValueFactory(new PropertyValueFactory<>("jumlah"));
        tabResepTable.setItems(tempResepList);

        // Setup RS ComboBoxes
        ObservableList<String> rsSoloList = FXCollections.observableArrayList(
            "RSUD Dr. Moewardi", "RS Kasih Ibu", "RS PKU Muhammadiyah Surakarta", "RS Panti Waluyo", "RS JIH Solo", "RS Hermina Solo"
        );
        if (rujukanRsComboBox != null) rujukanRsComboBox.setItems(rsSoloList);
        if (tabRujukanRsComboBox != null) tabRujukanRsComboBox.setItems(rsSoloList);

        // Setup Jenis Kelamin ComboBox
        if (pxJenisKelaminComboBox != null) {
            pxJenisKelaminComboBox.setItems(FXCollections.observableArrayList("Laki-laki", "Perempuan"));
        }

        // Setup Detail Resep Table
        if (detailResepTable != null) {
            detailResepTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
            colDetailResepNo.setCellValueFactory(new PropertyValueFactory<>("no"));
            colDetailResepObat.setCellValueFactory(new PropertyValueFactory<>("namaObat"));
            colDetailResepDosis.setCellValueFactory(new PropertyValueFactory<>("dosis"));
            colDetailResepAturan.setCellValueFactory(new PropertyValueFactory<>("aturanPakai"));
            colDetailResepJumlah.setCellValueFactory(new PropertyValueFactory<>("jumlah"));
        }

        // Setup Double-click listeners for tables
        if (resepTable != null) {
            resepTable.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !resepTable.getSelectionModel().isEmpty()) {
                    showResepDetail(resepTable.getSelectionModel().getSelectedItem());
                }
            });
        }
        
        if (rujukanTable != null) {
            rujukanTable.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !rujukanTable.getSelectionModel().isEmpty()) {
                    showRujukanDetail(rujukanTable.getSelectionModel().getSelectedItem());
                }
            });
        }

        // Load statistics and today's patients
        loadDashboardStats();
        loadDashboardTable();
    }

    private void configureNoColumn(TableColumn<Patient, ?> col) {
        if (col != null) {
            col.setText("No.");
            col.setMaxWidth(70);
            col.setMinWidth(50);
            col.setPrefWidth(60);
        }
    }

    private void setupPatientComboBox(ComboBox<Patient> combo) {
        if (combo == null) return;
        combo.setCellFactory(lv -> new ListCell<Patient>() {
            @Override
            protected void updateItem(Patient item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "" : item.getNamaPasien());
            }
        });
        combo.setButtonCell(new ListCell<Patient>() {
            @Override
            protected void updateItem(Patient item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "" : item.getNamaPasien());
            }
        });
    }

    // --- Navigation ---
    private void hideAllViews() {
        dashboardView.setVisible(false);
        dashboardView.setManaged(false);
        rekamMedisView.setVisible(false);
        rekamMedisView.setManaged(false);
        detailPeriksaView.setVisible(false);
        detailPeriksaView.setManaged(false);
        resepObatView.setVisible(false);
        resepObatView.setManaged(false);
        rujukanView.setVisible(false);
        rujukanView.setManaged(false);
    }

    private void highlightMenuButton(Button activeBtn) {
        Button[] buttons = {btnMenuDashboard, btnMenuRekamMedis, btnMenuResepObat, btnMenuRujukan};
        for (Button b : buttons) {
            if (b != null) {
                if (b == activeBtn) {
                    b.getStyleClass().remove("sidebar-btn");
                    if (!b.getStyleClass().contains("sidebar-btn-active")) {
                        b.getStyleClass().add("sidebar-btn-active");
                    }
                } else {
                    b.getStyleClass().remove("sidebar-btn-active");
                    if (!b.getStyleClass().contains("sidebar-btn")) {
                        b.getStyleClass().add("sidebar-btn");
                    }
                }
            }
        }
    }

    @FXML
    private void handleMenuDashboard() {
        hideAllViews();
        dashboardView.setVisible(true);
        dashboardView.setManaged(true);
        highlightMenuButton(btnMenuDashboard);
        loadDashboardStats();
        loadDashboardTable();
    }

    @FXML
    private void handleMenuRekamMedis() {
        hideAllViews();
        rekamMedisView.setVisible(true);
        rekamMedisView.setManaged(true);
        highlightMenuButton(btnMenuRekamMedis);
        loadRekamMedisData();
    }

    @FXML
    private void handleMenuResepObat() {
        hideAllViews();
        resepObatView.setVisible(true);
        resepObatView.setManaged(true);
        highlightMenuButton(btnMenuResepObat);
        loadResepObatData();
        loadPatientsList();
    }

    @FXML
    private void handleMenuRujukan() {
        hideAllViews();
        rujukanView.setVisible(true);
        rujukanView.setManaged(true);
        highlightMenuButton(btnMenuRujukan);
        loadRujukanData();
        loadPatientsList();
    }

    // --- Data Loaders & Filters ---
    private void loadDashboardStats() {
        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;
            
            // 1. Pasien Hari Ini (all active queues)
            String q1 = "SELECT COUNT(*) FROM antrian";
            try (PreparedStatement ps = conn.prepareStatement(q1)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) lblStatPasienHariIni.setText(String.valueOf(rs.getInt(1)));
                }
            }
            
            // 2. Rekam Medis
            String q2 = "SELECT COUNT(*) FROM rekam_medis";
            try (PreparedStatement ps = conn.prepareStatement(q2)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) lblStatRekamMedis.setText(String.valueOf(rs.getInt(1)));
                }
            }
            
            // 3. Resep Obat
            String q3 = "SELECT COUNT(*) FROM resep_obat";
            try (PreparedStatement ps = conn.prepareStatement(q3)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) lblStatResepObat.setText(String.valueOf(rs.getInt(1)));
                }
            }
            
            // 4. Rujukan
            String q4 = "SELECT COUNT(*) FROM surat_rujukan";
            try (PreparedStatement ps = conn.prepareStatement(q4)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) lblStatRujukan.setText(String.valueOf(rs.getInt(1)));
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadDashboardTable() {
        dashboardList.clear();
        
        String sql = "SELECT a.id_antrian, a.no_antrian, p.nama_pasien, a.tanggal_antrian, a.keluhan, a.status "
                   + "FROM antrian a "
                   + "JOIN pasien p ON a.id_pasien = p.id_pasien "
                   + "WHERE a.status IN ('Diverifikasi', 'Selesai') "
                   + "ORDER BY a.tanggal_antrian DESC, a.no_antrian ASC";
                   
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                int count = 1;
                while (rs.next()) {
                    Patient pat = new Patient(
                        rs.getInt("id_antrian"),
                        count++,
                        rs.getString("nama_pasien"),
                        rs.getDate("tanggal_antrian").toLocalDate(),
                        rs.getString("status"),
                        rs.getString("keluhan"),
                        "", "", null, ""
                    );
                    dashboardList.add(pat);
                }
                tableView.setItems(dashboardList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadRekamMedisData() {
        queueList.clear();
        
        String sql = "SELECT a.id_antrian, a.no_antrian, p.nama_pasien, a.tanggal_antrian, a.keluhan, a.status, "
                   + "       p.jenis_kelamin, p.no_hp, p.alamat, p.tanggal_lahir, p.id_pasien "
                   + "FROM antrian a "
                   + "JOIN pasien p ON a.id_pasien = p.id_pasien "
                   + "WHERE a.status IN ('Diverifikasi', 'Selesai') "
                   + "ORDER BY a.tanggal_antrian DESC, a.no_antrian ASC";
                   
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                int count = 1;
                while (rs.next()) {
                    LocalDate bday = rs.getDate("tanggal_lahir") != null ? rs.getDate("tanggal_lahir").toLocalDate() : null;
                    Patient pat = new Patient(
                        rs.getInt("id_antrian"),
                        count++,
                        rs.getString("nama_pasien"),
                        rs.getDate("tanggal_antrian").toLocalDate(),
                        rs.getString("status"),
                        rs.getString("keluhan"),
                        rs.getString("no_hp"),
                        rs.getString("alamat"),
                        bday,
                        rs.getString("jenis_kelamin")
                    );
                    pat.setIdTagihan(rs.getInt("id_pasien")); // temporary borrow id_pasien mapping
                    queueList.add(pat);
                }
                filterRekamMedisData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterRekamMedisData() {
        String query = rmSearchField.getText().toLowerCase().trim();
        ObservableList<Patient> filtered = FXCollections.observableArrayList();
        int count = 1;
        
        for (Patient p : queueList) {
            if (query.isEmpty() || p.getNamaPasien().toLowerCase().contains(query)) {
                Patient viewItem = new Patient(
                    p.getIdAntrian(),
                    count++,
                    p.getNamaPasien(),
                    p.getTanggalDaftar(),
                    p.getStatus(),
                    p.getKeluhan(),
                    p.getNoHp(),
                    p.getAlamat(),
                    p.getTanggalLahir(),
                    p.getJenisKelamin()
                );
                viewItem.setIdTagihan(p.getIdTagihan()); // hold patient ID
                filtered.add(viewItem);
            }
        }
        rekamMedisTable.setItems(filtered);
    }

    private void loadResepObatData() {
        resepList.clear();
        
        String sql = "SELECT r.id_resep, r.obat, r.aturan_pakai, r.tanggal, p.nama_pasien, r.id_pasien "
                   + "FROM resep_obat r "
                   + "JOIN pasien p ON r.id_pasien = p.id_pasien "
                   + "ORDER BY r.tanggal DESC, r.id_resep DESC";
                   
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                int count = 1;
                while (rs.next()) {
                    Patient pat = new Patient(
                        0, count++,
                        rs.getString("nama_pasien"),
                        rs.getDate("tanggal").toLocalDate(),
                        "Lunas", "", "", "", null, ""
                    );
                    pat.setIdResep(rs.getInt("id_resep"));
                    pat.setObat(rs.getString("obat"));
                    pat.setAturanPakai(rs.getString("aturan_pakai"));
                    resepList.add(pat);
                }
                filterResepData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterResepData() {
        String query = resepSearchField.getText().toLowerCase().trim();
        ObservableList<Patient> filtered = FXCollections.observableArrayList();
        int count = 1;
        
        for (Patient p : resepList) {
            if (query.isEmpty() || p.getNamaPasien().toLowerCase().contains(query)) {
                Patient viewItem = new Patient(
                    0, count++,
                    p.getNamaPasien(),
                    p.getTanggalDaftar(),
                    p.getStatus(),
                    p.getKeluhan(),
                    p.getNoHp(),
                    p.getAlamat(),
                    p.getTanggalLahir(),
                    p.getJenisKelamin()
                );
                viewItem.setIdResep(p.getIdResep());
                viewItem.setObat(p.getObat());
                viewItem.setAturanPakai(p.getAturanPakai());
                filtered.add(viewItem);
            }
        }
        resepTable.setItems(filtered);
    }

    private void loadRujukanData() {
        rujukanList.clear();
        
        String sql = "SELECT r.id_rujukan, r.rs_tujuan, r.diagnosa, r.tanggal, p.nama_pasien "
                   + "FROM surat_rujukan r "
                   + "JOIN pasien p ON r.id_pasien = p.id_pasien "
                   + "ORDER BY r.tanggal DESC, r.id_rujukan DESC";
                   
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                int count = 1;
                while (rs.next()) {
                    Patient pat = new Patient(
                        0, count++,
                        rs.getString("nama_pasien"),
                        rs.getDate("tanggal").toLocalDate(),
                        "Lunas", "", "", "", null, ""
                    );
                    pat.setIdRujukan(rs.getInt("id_rujukan"));
                    pat.setRsTujuan(rs.getString("rs_tujuan"));
                    pat.setDiagnosa(rs.getString("diagnosa"));
                    rujukanList.add(pat);
                }
                filterRujukanData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterRujukanData() {
        String query = rujukanSearchField.getText().toLowerCase().trim();
        ObservableList<Patient> filtered = FXCollections.observableArrayList();
        int count = 1;
        
        for (Patient p : rujukanList) {
            if (query.isEmpty() || p.getNamaPasien().toLowerCase().contains(query)) {
                Patient viewItem = new Patient(
                    0, count++,
                    p.getNamaPasien(),
                    p.getTanggalDaftar(),
                    p.getStatus(),
                    p.getKeluhan(),
                    p.getNoHp(),
                    p.getAlamat(),
                    p.getTanggalLahir(),
                    p.getJenisKelamin()
                );
                viewItem.setIdRujukan(p.getIdRujukan());
                viewItem.setRsTujuan(p.getRsTujuan());
                viewItem.setDiagnosa(p.getDiagnosa());
                filtered.add(viewItem);
            }
        }
        rujukanTable.setItems(filtered);
    }

    private void loadPatientsList() {
        allPatientsList.clear();
        String sql = "SELECT id_pasien, nama_pasien FROM pasien ORDER BY nama_pasien ASC";
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Patient p = new Patient(0, 0, rs.getString("nama_pasien"), null, "", "", "", "", null, "");
                p.setIdTagihan(rs.getInt("id_pasien")); // borrow idTagihan for patient ID mapping
                allPatientsList.add(p);
            }
            resepPasienComboBox.setItems(allPatientsList);
            rujukanPasienComboBox.setItems(allPatientsList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- Action Handlers ---

    private void handlePeriksaPasien(Patient patient) {
        selectedPatientForPemeriksaan = patient;
        pxNamaField.clear();
        pxKeluhanField.clear();
        if (pxJenisKelaminComboBox != null) pxJenisKelaminComboBox.setValue(null);
        if (pxTanggalLahirPicker != null) pxTanggalLahirPicker.setValue(null);
        pxNoHpField.clear();
        pxAlamatField.clear();
        
        tempRmList.clear();
        if (inputRmDiagnosis != null) inputRmDiagnosis.clear();
        if (inputRmTindakan != null) inputRmTindakan.clear();
        if (inputRmCatatan != null) inputRmCatatan.clear();

        // Clear temporary state & tab inputs
        tempResepList.clear();
        tabResepObatField.clear();
        tabResepDosisField.clear();
        tabResepAturanField.clear();
        tabResepJumlahField.clear();
        
        tabRujukanRsComboBox.setValue(null);
        tabRujukanDiagnosaField.clear();
        tabRujukanCatatanField.clear();

        hideAllViews();
        detailPeriksaView.setVisible(true);
        detailPeriksaView.setManaged(true);
    }

    @FXML
    private void handleTabAddRmItem() {
        String diagnosis = inputRmDiagnosis.getText().trim();
        String tindakan = inputRmTindakan.getText().trim();
        String catatan = inputRmCatatan.getText().trim();
        
        if (diagnosis.isEmpty() || tindakan.isEmpty()) {
            showAlert("Input Tidak Lengkap", "Silakan isi Diagnosis dan Tindakan Medis.");
            return;
        }
        
        int nextNo = tempRmList.size() + 1;
        tempRmList.add(new RmItem(nextNo, diagnosis, tindakan, catatan));
        
        inputRmDiagnosis.clear();
        inputRmTindakan.clear();
        inputRmCatatan.clear();
    }

    @FXML
    private void handleCancelPemeriksaan() {
        selectedPatientForPemeriksaan = null;
        tempRmList.clear();
        tempResepList.clear();
        tempRujukan = null;
        hideAllViews();
        rekamMedisView.setVisible(true);
        rekamMedisView.setManaged(true);
    }

    @FXML
    private void handleSavePemeriksaan() {
        if (selectedPatientForPemeriksaan == null) return;

        if (tempRmList.isEmpty()) {
            showAlert("Validasi Pemeriksaan", "Harap isi minimal satu baris data Pemeriksaan (Diagnosis dan Tindakan) melalui tabel.");
            return;
        }

        StringBuilder diagBuilder = new StringBuilder();
        StringBuilder tindBuilder = new StringBuilder();
        StringBuilder catBuilder = new StringBuilder();
        for (RmItem item : tempRmList) {
            if (diagBuilder.length() > 0) diagBuilder.append("\n");
            diagBuilder.append(item.getNo()).append(". ").append(item.getDiagnosis());
            if (tindBuilder.length() > 0) tindBuilder.append("\n");
            tindBuilder.append(item.getNo()).append(". ").append(item.getTindakan());
            if (!item.getCatatan().isEmpty()) {
                if (catBuilder.length() > 0) catBuilder.append("\n");
                catBuilder.append(item.getNo()).append(". ").append(item.getCatatan());
            }
        }
        String diagnosa = diagBuilder.toString();
        String tindakan = tindBuilder.toString();
        String catatan = catBuilder.toString();

        // Build Resep Obat and Aturan Pakai from tempResepList
        StringBuilder resepObatBuilder = new StringBuilder();
        StringBuilder aturanPakaiBuilder = new StringBuilder();
        for (ResepItem item : tempResepList) {
            if (resepObatBuilder.length() > 0) {
                resepObatBuilder.append("\n");
                aturanPakaiBuilder.append(", ");
            }
            resepObatBuilder.append(item.getNo()).append(". ")
                            .append(item.getNamaObat()).append(" ")
                            .append(item.getDosis()).append(" (Jml: ")
                            .append(item.getJumlah()).append(")");
            aturanPakaiBuilder.append(item.getNamaObat()).append(": ")
                              .append(item.getAturanPakai());
        }
        String resepObat = resepObatBuilder.toString();
        String aturanPakai = aturanPakaiBuilder.toString();

        // Build Rujukan data from tab
        String rujukanRs = tabRujukanRsComboBox.getValue() != null ? tabRujukanRsComboBox.getValue().trim() : "";
        String rujDiag = tabRujukanDiagnosaField.getText().trim();
        String rujCatatan = tabRujukanCatatanField.getText().trim();
        String rujukanDiagnosa = !rujDiag.isEmpty() ? (rujDiag + (rujCatatan.isEmpty() ? "" : "\nCatatan: " + rujCatatan)) : "";

        if (diagnosa.isEmpty() || tindakan.isEmpty()) {
            showAlert("Validasi Pemeriksaan", "Data pemeriksaan kosong.");
            return;
        }

        int docId = App.getLoggedInDoctorId() > 0 ? App.getLoggedInDoctorId() : 1;
        int patientId = selectedPatientForPemeriksaan.getIdTagihan(); // stored in idTagihan column

        // Show loading spinner
        loadingOverlay.setVisible(true);
        loadingOverlay.setManaged(true);

        PauseTransition loadPause = new PauseTransition(Duration.seconds(1.2));
        loadPause.setOnFinished(event -> {
            Connection conn = null;
            try {
                conn = Database.getConnection();
                conn.setAutoCommit(false);

                // 1. Insert Pemeriksaan
                String sqlPem = "INSERT INTO pemeriksaan (id_antrian, diagnosa, tindakan, tanggal_pemeriksaan) VALUES (?, ?, ?, NOW())";
                int pemId = -1;
                try (PreparedStatement psPem = conn.prepareStatement(sqlPem, Statement.RETURN_GENERATED_KEYS)) {
                    psPem.setInt(1, selectedPatientForPemeriksaan.getIdAntrian());
                    psPem.setString(2, diagnosa);
                    psPem.setString(3, tindakan);
                    psPem.executeUpdate();
                    try (ResultSet rsKeys = psPem.getGeneratedKeys()) {
                        if (rsKeys.next()) pemId = rsKeys.getInt(1);
                    }
                }

                if (pemId == -1) throw new SQLException("Gagal mencatat pemeriksaan medis.");

                // 2. Insert Rekam Medis
                String sqlRm = "INSERT INTO rekam_medis (id_pasien, id_dokter, id_pemeriksaan, tanggal, keluhan, diagnosa, tindakan, catatan) "
                             + "VALUES (?, ?, ?, CURRENT_DATE(), ?, ?, ?, ?)";
                try (PreparedStatement psRm = conn.prepareStatement(sqlRm)) {
                    psRm.setInt(1, patientId);
                    psRm.setInt(2, docId);
                    psRm.setInt(3, pemId);
                    psRm.setString(4, selectedPatientForPemeriksaan.getKeluhan());
                    psRm.setString(5, diagnosa);
                    psRm.setString(6, tindakan);
                    psRm.setString(7, catatan);
                    psRm.executeUpdate();
                }

                // 3. Update Antrian status to 'Selesai'
                String sqlAnt = "UPDATE antrian SET status = 'Selesai' WHERE id_antrian = ?";
                try (PreparedStatement psAnt = conn.prepareStatement(sqlAnt)) {
                    psAnt.setInt(1, selectedPatientForPemeriksaan.getIdAntrian());
                    psAnt.executeUpdate();
                }

                // 4. Auto-generate patient billing in 'tagihan' (biaya pemeriksaan 100k + admin 15k = 115k)
                String sqlBill = "INSERT INTO tagihan (id_pasien, id_antrian, biaya_pemeriksaan, biaya_admin, total_tagihan, status, tanggal) "
                               + "VALUES (?, ?, 100000.00, 15000.00, 115000.00, 'Belum Lunas', CURRENT_DATE())";
                try (PreparedStatement psBill = conn.prepareStatement(sqlBill)) {
                    psBill.setInt(1, patientId);
                    psBill.setInt(2, selectedPatientForPemeriksaan.getIdAntrian());
                    psBill.executeUpdate();
                }

                // 5. Optional Resep Obat
                if (!resepObat.isEmpty() && !aturanPakai.isEmpty()) {
                    String sqlResep = "INSERT INTO resep_obat (id_pasien, id_dokter, obat, aturan_pakai, tanggal) VALUES (?, ?, ?, ?, CURRENT_DATE())";
                    try (PreparedStatement psResep = conn.prepareStatement(sqlResep)) {
                        psResep.setInt(1, patientId);
                        psResep.setInt(2, docId);
                        psResep.setString(3, resepObat);
                        psResep.setString(4, aturanPakai);
                        psResep.executeUpdate();
                    }
                }

                // 6. Optional Rujukan
                if (!rujukanRs.isEmpty() && !rujukanDiagnosa.isEmpty()) {
                    String sqlRujuk = "INSERT INTO surat_rujukan (id_pasien, id_dokter, rs_tujuan, diagnosa, tanggal) VALUES (?, ?, ?, ?, CURRENT_DATE())";
                    try (PreparedStatement psRujuk = conn.prepareStatement(sqlRujuk)) {
                        psRujuk.setInt(1, patientId);
                        psRujuk.setInt(2, docId);
                        psRujuk.setString(3, rujukanRs);
                        psRujuk.setString(4, rujukanDiagnosa);
                        psRujuk.executeUpdate();
                    }
                }

                conn.commit();
                System.out.println("Pemeriksaan dan Rekam Medis ID " + pemId + " sukses disimpan.");
                tempResepList.clear();
                tempRujukan = null;

            } catch (Exception e) {
                if (conn != null) {
                    try {
                        conn.rollback();
                    } catch (SQLException ex) {
                        showErrorAlert("Gagal rollback data rekam medis", ex);
                    }
                }
                showErrorAlert("Gagal menyimpan Rekam Medis ke database", e);
            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        showErrorAlert("Gagal menutup koneksi database", ex);
                    }
                }
            }

            loadingOverlay.setVisible(false);
            loadingOverlay.setManaged(false);

            // Show Success checkmark
            successOverlay.setVisible(true);
            successOverlay.setManaged(true);

            PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
            successPause.setOnFinished(se -> {
                successOverlay.setVisible(false);
                successOverlay.setManaged(false);
                
                // Back to lists
                handleMenuRekamMedis();
            });
            successPause.play();
        });
        loadPause.play();
    }

    private void handleViewRekamMedisDetail(Patient patient) {
        // Simple alert showing the diagnosis detail
        int patientId = patient.getIdTagihan();
        String detailMsg = "Pemeriksaan Selesai\n\nPasien: " + patient.getNamaPasien() + "\nTanggal: " + patient.getTanggalDaftar();
        
        String sql = "SELECT diagnosa, tindakan, catatan FROM rekam_medis WHERE id_pasien = ? ORDER BY id_rekam_medis DESC LIMIT 1";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    detailMsg += "\n\nDiagnosa:\n- " + rs.getString("diagnosa")
                               + "\n\nTindakan:\n- " + rs.getString("tindakan")
                               + "\n\nCatatan:\n- " + rs.getString("catatan");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle("Detail Rekam Medis");
        alert.setHeaderText(null);
        alert.setContentText(detailMsg);
        alert.showAndWait();
    }

    @FXML
    private void handleSaveResep() {
        Patient selectedPat = resepPasienComboBox.getValue();
        String obat = resepObatArea.getText().trim();
        String aturanPakai = resepAturanField.getText().trim();

        if (selectedPat == null || obat.isEmpty() || aturanPakai.isEmpty()) {
            showAlert("Validasi Resep", "Harap lengkapi semua data Resep.");
            return;
        }

        int docId = App.getLoggedInDoctorId() > 0 ? App.getLoggedInDoctorId() : 1;
        int patientId = selectedPat.getIdTagihan();

        loadingOverlay.setVisible(true);
        loadingOverlay.setManaged(true);

        PauseTransition pause = new PauseTransition(Duration.seconds(1.2));
        pause.setOnFinished(e -> {
            String sql = "INSERT INTO resep_obat (id_pasien, id_dokter, obat, aturan_pakai, tanggal) VALUES (?, ?, ?, ?, CURRENT_DATE())";
            try (Connection conn = Database.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, patientId);
                ps.setInt(2, docId);
                ps.setString(3, obat);
                ps.setString(4, aturanPakai);
                ps.executeUpdate();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            loadingOverlay.setVisible(false);
            loadingOverlay.setManaged(false);

            successOverlay.setVisible(true);
            successOverlay.setManaged(true);

            PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
            successPause.setOnFinished(se -> {
                successOverlay.setVisible(false);
                successOverlay.setManaged(false);

                // Clear input
                resepPasienComboBox.setValue(null);
                resepObatArea.clear();
                resepAturanField.clear();

                // Refresh data
                loadResepObatData();
            });
            successPause.play();
        });
        pause.play();
    }

    @FXML
    private void handleSaveRujukan() {
        Patient selectedPat = rujukanPasienComboBox.getValue();
        String rsTujuan = rujukanRsComboBox.getValue() != null ? rujukanRsComboBox.getValue().trim() : "";
        String diagnosa = rujukanDiagnosaArea.getText().trim();

        if (selectedPat == null || rsTujuan.isEmpty() || diagnosa.isEmpty()) {
            showAlert("Validasi Rujukan", "Harap lengkapi semua data surat Rujukan.");
            return;
        }

        int docId = App.getLoggedInDoctorId() > 0 ? App.getLoggedInDoctorId() : 1;
        int patientId = selectedPat.getIdTagihan();

        loadingOverlay.setVisible(true);
        loadingOverlay.setManaged(true);

        PauseTransition pause = new PauseTransition(Duration.seconds(1.2));
        pause.setOnFinished(e -> {
            String sql = "INSERT INTO surat_rujukan (id_pasien, id_dokter, rs_tujuan, diagnosa, tanggal) VALUES (?, ?, ?, ?, CURRENT_DATE())";
            try (Connection conn = Database.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, patientId);
                ps.setInt(2, docId);
                ps.setString(3, rsTujuan);
                ps.setString(4, diagnosa);
                ps.executeUpdate();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            loadingOverlay.setVisible(false);
            loadingOverlay.setManaged(false);

            successOverlay.setVisible(true);
            successOverlay.setManaged(true);

            PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
            successPause.setOnFinished(se -> {
                successOverlay.setVisible(false);
                successOverlay.setManaged(false);

                // Clear input
                rujukanPasienComboBox.setValue(null);
                rujukanRsComboBox.setValue(null);
                rujukanDiagnosaArea.clear();

                // Refresh data
                loadRujukanData();
            });
            successPause.play();
        });
        pause.play();
    }

    // --- Logout Overlay ---
    @FXML
    private void showLogoutModal() {
        logoutOverlay.setVisible(true);
        logoutOverlay.setManaged(true);
    }

    @FXML
    private void handleLogoutYes() throws IOException {
        App.setRoot("primary");
    }

    @FXML
    private void handleLogoutNo() {
        logoutOverlay.setVisible(false);
        logoutOverlay.setManaged(false);
    }

    // --- Resep & Rujukan Tab Logic ---
    @FXML
    private void handleTabAddResepItem() {
        String obat = tabResepObatField.getText().trim();
        String dosis = tabResepDosisField.getText().trim();
        String aturan = tabResepAturanField.getText().trim();
        String jumlah = tabResepJumlahField.getText().trim();

        if (obat.isEmpty() || dosis.isEmpty() || aturan.isEmpty() || jumlah.isEmpty()) {
            showAlert("Validasi Obat", "Harap lengkapi seluruh field obat.");
            return;
        }

        int nextNo = tempResepList.size() + 1;
        ResepItem item = new ResepItem(nextNo, obat, dosis, aturan, jumlah);
        tempResepList.add(item);

        tabResepObatField.clear();
        tabResepDosisField.clear();
        tabResepAturanField.clear();
        tabResepJumlahField.clear();
    }

    private void showAlert(String title, String content) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // --- Detail Modals Methods ---
    private void showResepDetail(Patient patient) {
        if (resepDetailModalOverlay == null) return;
        
        detailResepPasienLabel.setText(patient.getNamaPasien());
        String docName = App.getLoggedInDoctorName();
        detailResepTteDokterLabel.setText(docName != null && !docName.isEmpty() ? docName : "dr. Andi");
        detailResepSipLabel.setText("SIP: " + (docName != null ? "123.456.789" : "000.000.000"));
        
        ObservableList<ResepItem> items = FXCollections.observableArrayList();
        String fullResep = patient.getObat();
        // Mock parsing simple prescription string to ResepItem
        items.add(new ResepItem(1, fullResep != null ? fullResep : "-", "-", patient.getAturanPakai() != null ? patient.getAturanPakai() : "-", "-"));
        
        detailResepTable.setItems(items);
        resepDetailModalOverlay.setVisible(true);
        resepDetailModalOverlay.setManaged(true);
    }

    @FXML
    private void handleCloseResepDetail() {
        if (resepDetailModalOverlay != null) {
            resepDetailModalOverlay.setVisible(false);
            resepDetailModalOverlay.setManaged(false);
        }
    }

    private void showRujukanDetail(Patient patient) {
        if (rujukanDetailModalOverlay == null) return;
        
        detailRujukanPasienLabel.setText(patient.getNamaPasien());
        detailRujukanRsLabel.setText(patient.getRsTujuan() != null ? patient.getRsTujuan() : "-");
        detailRujukanTanggalLabel.setText(patient.getTanggalDaftar() != null ? patient.getTanggalDaftar().toString() : "-");
        detailRujukanDiagnosaArea.setText(patient.getDiagnosa() != null ? patient.getDiagnosa() : "-");
        
        String docName = App.getLoggedInDoctorName();
        detailRujukanTteDokterLabel.setText(docName != null && !docName.isEmpty() ? docName : "dr. Andi");
        detailRujukanSipLabel.setText("SIP: " + (docName != null ? "123.456.789" : "000.000.000"));

        rujukanDetailModalOverlay.setVisible(true);
        rujukanDetailModalOverlay.setManaged(true);
    }

    @FXML
    private void handleCloseRujukanDetail() {
        if (rujukanDetailModalOverlay != null) {
            rujukanDetailModalOverlay.setVisible(false);
            rujukanDetailModalOverlay.setManaged(false);
        }
    }
    private void showErrorAlert(String header, Exception e) {
        javafx.application.Platform.runLater(() -> {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Terjadi Kesalahan Server");
            alert.setHeaderText(header);
            alert.setContentText("Detail Error: " + (e != null ? e.getMessage() : "Kesalahan Tidak Diketahui"));
            alert.showAndWait();
        });
    }
}
