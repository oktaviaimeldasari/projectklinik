package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginPasienController implements Initializable {
    
    // Login inputs
    @FXML private TextField loginPhoneField;
    @FXML private PasswordField loginPasswordField;
    @FXML private TextField loginPasswordTextField;
    @FXML private Button loginPassToggleBtn;
    @FXML private CheckBox loginKeepLoggedIn;
    
    // Output label
    @FXML private Label loginErrorLabel;

    private boolean isLoginPassVisible = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clearLoginFields();
        
        // Cek jika user sudah login di session global
        int activeUserId = App.getLoggedInUserId();
        if (activeUserId > 0) {
            System.out.println("User sudah login dengan ID: " + activeUserId);
            // TODO: Arahkan ke Dashboard Pasien ketika FXML-nya sudah tersedia
        }
    }

    private void clearLoginFields() {
        if (loginPhoneField != null) loginPhoneField.clear();
        if (loginPasswordField != null) loginPasswordField.clear();
        if (loginPasswordTextField != null) loginPasswordTextField.clear();
        if (loginErrorLabel != null) loginErrorLabel.setVisible(false);
        isLoginPassVisible = false;
        
        if (loginPasswordField != null) loginPasswordField.setVisible(true);
        if (loginPasswordTextField != null) loginPasswordTextField.setVisible(false);
        if (loginPassToggleBtn != null) loginPassToggleBtn.setText("👁");
    }

    @FXML
    private void handleToggleLoginPass() {
        if (isLoginPassVisible) {
            loginPasswordField.setText(loginPasswordTextField.getText());
            loginPasswordTextField.setVisible(false);
            loginPasswordField.setVisible(true);
            loginPassToggleBtn.setText("👁");
            isLoginPassVisible = false;
        } else {
            loginPasswordTextField.setText(loginPasswordField.getText());
            loginPasswordField.setVisible(false);
            loginPasswordTextField.setVisible(true);
            loginPassToggleBtn.setText("🔒");
            isLoginPassVisible = true;
        }
    }

    @FXML
    private void handleLogin() {
        String phone = loginPhoneField.getText().trim();
        String password = isLoginPassVisible ? loginPasswordTextField.getText() : loginPasswordField.getText();

        if (phone.isEmpty() || password.isEmpty()) {
            if (loginErrorLabel != null) {
                loginErrorLabel.setText("No HP dan kata sandi harus diisi!");
                loginErrorLabel.setVisible(true);
            }
            return;
        }

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                if (loginErrorLabel != null) {
                    loginErrorLabel.setText("Database tidak terhubung!");
                    loginErrorLabel.setVisible(true);
                }
                return;
            }

            // Query user role 3 (Pasien)
            String sql = "SELECT u.id_user, p.nama_pasien FROM user u "
                       + "LEFT JOIN pasien p ON u.id_pasien = p.id_pasien "
                       + "WHERE u.username = ? AND u.password = ? AND u.id_role = 3";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, phone);
                ps.setString(2, password);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        App.setLoggedInUserId(rs.getInt("id_user"));
                        App.setLoggedInUsername(phone);
                        App.setLoggedInDoctorId(0);
                        App.setLoggedInDoctorName(null);

                        System.out.println("Login Pasien Sukses: " + rs.getString("nama_pasien"));
                        App.setRoot("DashboardPasien");
                    } else {
                        if (loginErrorLabel != null) {
                            loginErrorLabel.setText("No HP atau kata sandi salah!");
                            loginErrorLabel.setVisible(true);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (loginErrorLabel != null) {
                loginErrorLabel.setText("Error: " + e.getMessage());
                loginErrorLabel.setVisible(true);
            }
        }
    }

    @FXML
    private void showRegister() throws IOException {
        App.setRoot("RegisterPasien");
    }

    @FXML
    private void showWelcome() throws IOException {
        App.setRoot("WelcomePasien");
    }

    @FXML
    private void goToLupaSandi() throws IOException {
        App.setRoot("LupaSandiPasien");
    }
}
