package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import com.mycompany.projectklinik.model.Patient;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class SecondaryController implements Initializable {

    // Main Stack Views
    @FXML private VBox dashboardView;
    @FXML private VBox verifikasiView;
    @FXML private VBox detailView;
    @FXML private VBox pasienOfflineView;
    @FXML private VBox kelolaPendaftaranView;
    @FXML private VBox arsipRekamMedisView;
    @FXML private VBox detailRekamMedisView;
    @FXML private VBox kelolaTagihanView;
    @FXML private VBox lihatTagihanView;

    // Sidebar buttons
    @FXML private Button btnMenuDashboard;
    @FXML private Button btnMenuVerifikasi;
    @FXML private Button btnMenuPasienOffline;
    @FXML private Button btnMenuKelolaPendaftaran;
    @FXML private Button btnMenuArsipRekamMedis;
    @FXML private Button btnMenuKelolaTagihan;

    // Kelola Tagihan View Controls
    @FXML private ComboBox<String> kelolaTagihanStatusComboBox;
    @FXML private DatePicker kelolaTagihanDariDatePicker;
    @FXML private DatePicker kelolaTagihanSampaiDatePicker;
    @FXML private TextField kelolaTagihanSearchField;
    @FXML private TableView<Patient> kelolaTagihanTable;
    @FXML private TableColumn<Patient, Integer> colTagihanNo;
    @FXML private TableColumn<Patient, String> colTagihanNoTagihan;
    @FXML private TableColumn<Patient, String> colTagihanNama;
    @FXML private TableColumn<Patient, LocalDate> colTagihanTanggal;
    @FXML private TableColumn<Patient, Double> colTagihanTotal;
    @FXML private TableColumn<Patient, String> colTagihanAksi;

    // Lihat Kelola Tagihan View Controls
    @FXML private TextField billDetailPemeriksaan;
    @FXML private TextField billDetailAdmin;
    @FXML private TextField billDetailTotal;
    @FXML private TextField billDetailStatus;

    // Modal Overlays for Payment
    @FXML private StackPane bayarOverlay;
    @FXML private TextField payNamaPasien;
    @FXML private TextField payTotalTagihan;

    @FXML private StackPane tunaiOverlay;
    @FXML private TextField cashTotalTagihan;
    @FXML private TextField cashUangDiterima;
    @FXML private TextField cashKembalian;

    @FXML private StackPane qrisOverlay;
    @FXML private ImageView qrisImageView;

    // Dashboard View Controls
    @FXML private TableView<Patient> tableView;
    @FXML private TableColumn<Patient, Integer> colNo;
    @FXML private TableColumn<Patient, String> colNama;
    @FXML private TableColumn<Patient, LocalDate> colTanggal;
    @FXML private TableColumn<Patient, String> colStatus;

    // Verifikasi View Controls
    @FXML private TableView<Patient> verifikasiTable;
    @FXML private TableColumn<Patient, Integer> colVerifNo;
    @FXML private TableColumn<Patient, String> colVerifNama;
    @FXML private TableColumn<Patient, String> colVerifNoHp;
    @FXML private TableColumn<Patient, LocalDate> colVerifTanggal;
    @FXML private TableColumn<Patient, String> colVerifStatus;
    @FXML private TableColumn<Patient, String> colVerifAksi;
    @FXML private ComboBox<String> statusFilterComboBox;
    @FXML private TextField searchField;

    // Detail View Controls
    @FXML private TextField detailNamaField;
    @FXML private TextField detailNikField;
    @FXML private TextField detailAlamatField;
    @FXML private TextField detailTglLahirField;
    @FXML private TextArea detailKeluhanArea;

    // Overlay Modals
    @FXML private StackPane logoutOverlay;
    @FXML private StackPane confirmActionOverlay;
    @FXML private StackPane loadingOverlay;
    @FXML private StackPane successOverlay;
    @FXML private StackPane confirmOfflineOverlay;
    @FXML private StackPane successOfflineOverlay;

    // Pasien Offline Form Fields
    @FXML private TextField offlineNamaField;
    @FXML private DatePicker offlineTglLahirDatePicker;
    @FXML private ComboBox<String> offlineJkComboBox;
    @FXML private TextField offlineNikField;
    @FXML private TextField offlineNoHpField;
    @FXML private TextField offlineAlamatField;
    @FXML private TextField offlineTglDaftarField;
    @FXML private TextArea offlineKeluhanArea;

    // Kelola Pendaftaran Fields
    @FXML private ComboBox<String> kelolaStatusComboBox;
    @FXML private DatePicker kelolaDariDatePicker;
    @FXML private DatePicker kelolaSampaiDatePicker;
    @FXML private TableView<Patient> kelolaTable;
    @FXML private TableColumn<Patient, Integer> colKelolaNo;
    @FXML private TableColumn<Patient, String> colKelolaNama;
    @FXML private TableColumn<Patient, LocalDate> colKelolaTanggal;
    @FXML private TableColumn<Patient, String> colKelolaStatus;

    // Arsip Rekam Medis Fields
    @FXML private TextField arsipSearchField;
    @FXML private DatePicker arsipDariDatePicker;
    @FXML private DatePicker arsipSampaiDatePicker;
    @FXML private TableView<Patient> arsipTable;
    @FXML private TableColumn<Patient, Integer> colArsipNo;
    @FXML private TableColumn<Patient, String> colArsipNoRm;
    @FXML private TableColumn<Patient, String> colArsipNama;
    @FXML private TableColumn<Patient, LocalDate> colArsipTanggal;
    @FXML private TableColumn<Patient, String> colArsipAksi;

    // Detail Rekam Medis Fields (Frame 34)
    @FXML private TextField rmDetailNama;
    @FXML private TextField rmDetailNik;
    @FXML private TextField rmDetailAlamat;
    @FXML private TextField rmDetailTglLahir;
    @FXML private TextField rmDetailJk;
    @FXML private TextField rmDetailNoAntrian;
    @FXML private TextField rmDetailRiwayatKunjungan;
    @FXML private TextArea rmDetailDiagnosa;

    private ObservableList<Patient> dashboardList = FXCollections.observableArrayList();
    private ObservableList<Patient> verifikasiList = FXCollections.observableArrayList();
    private ObservableList<Patient> kelolaList = FXCollections.observableArrayList();
    private ObservableList<Patient> arsipList = FXCollections.observableArrayList();
    private ObservableList<Patient> tagihanList = FXCollections.observableArrayList();
    private Patient selectedPatientForVerification;
    private Patient selectedPatientForPayment;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Enable constrained resize policy to auto-fit columns to full desktop width
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        if (verifikasiTable != null) {
            verifikasiTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        }
        if (kelolaTable != null) {
            kelolaTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        }
        if (arsipTable != null) {
            arsipTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        }
        if (kelolaTagihanTable != null) {
            kelolaTagihanTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        }

        // Set 'No' columns width constraints and set text to "No."
        colNo.setText("No.");
        colNo.setMaxWidth(70);
        colNo.setMinWidth(50);
        colNo.setPrefWidth(60);
        
        colVerifNo.setText("No.");
        colVerifNo.setMaxWidth(70);
        colVerifNo.setMinWidth(50);
        colVerifNo.setPrefWidth(60);
        
        if (colKelolaNo != null) {
            colKelolaNo.setText("No.");
            colKelolaNo.setMaxWidth(70);
            colKelolaNo.setMinWidth(50);
            colKelolaNo.setPrefWidth(60);
        }
        if (colArsipNo != null) {
            colArsipNo.setText("No.");
            colArsipNo.setMaxWidth(70);
            colArsipNo.setMinWidth(50);
            colArsipNo.setPrefWidth(60);
        }
        if (colTagihanNo != null) {
            colTagihanNo.setText("No.");
            colTagihanNo.setMaxWidth(70);
            colTagihanNo.setMinWidth(50);
            colTagihanNo.setPrefWidth(60);
        }

        // Set full spelling for RM, billing, and HP column headers
        if (colArsipNoRm != null) {
            colArsipNoRm.setText("Nomor rekam medis");
            colArsipNoRm.setPrefWidth(180);
        }
        if (colTagihanNoTagihan != null) {
            colTagihanNoTagihan.setText("Nomor tagihan");
            colTagihanNoTagihan.setPrefWidth(150);
        }
        if (colVerifNoHp != null) {
            colVerifNoHp.setText("Nomor HP");
            colVerifNoHp.setPrefWidth(160);
        }

        // 1. Setup TableView Dashboard
        colNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // 2. Setup TableView Verifikasi
        colVerifNo.setCellValueFactory(new PropertyValueFactory<>("no"));
        colVerifNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
        colVerifNoHp.setCellValueFactory(new PropertyValueFactory<>("noHp"));
        colVerifTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
        colVerifStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        
        // Custom cell factory untuk menyisipkan button Aksi di kolom Aksi
        colVerifAksi.setCellFactory(column -> new TableCell<Patient, String>() {
            private final Button btn = new Button();

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    setText(null);
                } else {
                    Patient patient = getTableView().getItems().get(getIndex());
                    if ("Menunggu Verifikasi".equalsIgnoreCase(patient.getStatus())) {
                        btn.setText("Verifikasi");
                        btn.getStyleClass().clear();
                        btn.getStyleClass().add("btn-action-verify");
                        btn.setOnAction(event -> handleVerifyAction(patient));
                    } else {
                        btn.setText("Lihat");
                        btn.getStyleClass().clear();
                        btn.getStyleClass().add("btn-action-view");
                        btn.setOnAction(event -> handleViewAction(patient));
                    }
                    setGraphic(btn);
                    setText(null);
                }
            }
        });

        // 3. Setup Filter ComboBox
        statusFilterComboBox.setItems(FXCollections.observableArrayList("Semua status", "Menunggu Verifikasi", "Diverifikasi"));
        statusFilterComboBox.setValue("Semua status");
        statusFilterComboBox.setOnAction(event -> filterVerifikasiData());

        // 4. Setup Search Field Listener
        searchField.textProperty().addListener((observable, oldValue, newValue) -> filterVerifikasiData());

        // 5. Setup Pasien Offline ComboBox & Default Date
        if (offlineJkComboBox != null) {
            offlineJkComboBox.setItems(FXCollections.observableArrayList("Laki-laki", "Perempuan"));
            offlineJkComboBox.setValue("Laki-laki");
        }
        if (offlineTglDaftarField != null) {
            offlineTglDaftarField.setText(LocalDate.now().toString());
        }

        // 6. Setup TableView Kelola
        if (colKelolaNo != null) {
            colKelolaNo.setCellValueFactory(new PropertyValueFactory<>("no"));
            colKelolaNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
            colKelolaTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
            colKelolaStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        }
        if (kelolaStatusComboBox != null) {
            kelolaStatusComboBox.setItems(FXCollections.observableArrayList("Semua status", "Menunggu Verifikasi", "Diverifikasi"));
            kelolaStatusComboBox.setValue("Semua status");
            kelolaStatusComboBox.setOnAction(event -> filterKelolaData());
        }
        if (kelolaDariDatePicker != null) {
            kelolaDariDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterKelolaData());
            kelolaSampaiDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterKelolaData());
        }

        // 7. Setup TableView Arsip
        if (colArsipNo != null) {
            colArsipNo.setCellValueFactory(new PropertyValueFactory<>("no"));
            colArsipNoRm.setCellValueFactory(new PropertyValueFactory<>("noRm"));
            colArsipNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
            colArsipTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
            
            colArsipAksi.setCellFactory(column -> new TableCell<Patient, String>() {
                private final Button btn = new Button("Lihat");
                {
                    btn.getStyleClass().add("btn-action-view");
                    btn.setOnAction(event -> {
                        Patient patient = getTableView().getItems().get(getIndex());
                        handleViewRekamMedis(patient);
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        setGraphic(btn);
                    }
                }
            });
        }
        if (arsipSearchField != null) {
            arsipSearchField.textProperty().addListener((obs, oldVal, newVal) -> filterArsipData());
        }
        if (arsipDariDatePicker != null) {
            arsipDariDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterArsipData());
            arsipSampaiDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterArsipData());
        }

        // 8. Setup TableView Tagihan
        if (colTagihanNo != null) {
            colTagihanNo.setCellValueFactory(new PropertyValueFactory<>("no"));
            colTagihanNoTagihan.setCellValueFactory(new PropertyValueFactory<>("noTagihan"));
            colTagihanNama.setCellValueFactory(new PropertyValueFactory<>("namaPasien"));
            colTagihanTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalDaftar"));
            
            colTagihanTotal.setCellValueFactory(new PropertyValueFactory<>("totalTagihan"));
            colTagihanTotal.setCellFactory(column -> new TableCell<Patient, Double>() {
                @Override
                protected void updateItem(Double item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        setText(formatRupiah(item));
                    }
                }
            });

            colTagihanAksi.setCellFactory(column -> new TableCell<Patient, String>() {
                private final Button btnLihat = new Button("Lihat");
                private final Button btnBayar = new Button("Bayar");
                private final javafx.scene.layout.HBox container = new javafx.scene.layout.HBox(8, btnLihat, btnBayar);
                {
                    btnLihat.getStyleClass().add("btn-action-view");
                    btnLihat.setOnAction(event -> {
                        Patient patient = getTableView().getItems().get(getIndex());
                        handleViewTagihan(patient);
                    });

                    btnBayar.getStyleClass().add("btn-action-pay");
                    btnBayar.setOnAction(event -> {
                        Patient patient = getTableView().getItems().get(getIndex());
                        handlePayTagihan(patient);
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        Patient patient = getTableView().getItems().get(getIndex());
                        btnBayar.setVisible("Belum Lunas".equalsIgnoreCase(patient.getStatusTagihan()));
                        btnBayar.setManaged("Belum Lunas".equalsIgnoreCase(patient.getStatusTagihan()));
                        setGraphic(container);
                    }
                }
            });
        }
        
        if (kelolaTagihanStatusComboBox != null) {
            kelolaTagihanStatusComboBox.setItems(FXCollections.observableArrayList("Semua status", "Belum Lunas", "Lunas"));
            kelolaTagihanStatusComboBox.setValue("Semua status");
            kelolaTagihanStatusComboBox.setOnAction(event -> filterTagihanData());
        }
        
        if (kelolaTagihanDariDatePicker != null) {
            kelolaTagihanDariDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterTagihanData());
            kelolaTagihanSampaiDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> filterTagihanData());
        }
        
        if (kelolaTagihanSearchField != null) {
            kelolaTagihanSearchField.textProperty().addListener((obs, oldVal, newVal) -> filterTagihanData());
        }

        // 9. Setup Cash Change Listener
        if (cashUangDiterima != null) {
            cashUangDiterima.textProperty().addListener((observable, oldValue, newValue) -> {
                if (selectedPatientForPayment == null) return;
                try {
                    String cleaned = newValue.replaceAll("[^\\d]", "");
                    if (cleaned.isEmpty()) {
                        cashKembalian.setText("Rp 0");
                        return;
                    }
                    double received = Double.parseDouble(cleaned);
                    double total = selectedPatientForPayment.getTotalTagihan();
                    double change = received - total;
                    if (change < 0) {
                        cashKembalian.setText("Rp 0 (Kurang " + formatRupiah(Math.abs(change)) + ")");
                    } else {
                        cashKembalian.setText(formatRupiah(change));
                    }
                } catch (NumberFormatException e) {
                    cashKembalian.setText("Rp 0");
                }
            });
        }

        // Load initial data
        loadDashboardData();
    }

    // --- Sidebar Menu Handlers ---
    private void hideAllViews() {
        dashboardView.setVisible(false);
        dashboardView.setManaged(false);
        verifikasiView.setVisible(false);
        verifikasiView.setManaged(false);
        detailView.setVisible(false);
        detailView.setManaged(false);
        if (pasienOfflineView != null) {
            pasienOfflineView.setVisible(false);
            pasienOfflineView.setManaged(false);
        }
        if (kelolaPendaftaranView != null) {
            kelolaPendaftaranView.setVisible(false);
            kelolaPendaftaranView.setManaged(false);
        }
        if (arsipRekamMedisView != null) {
            arsipRekamMedisView.setVisible(false);
            arsipRekamMedisView.setManaged(false);
        }
        if (detailRekamMedisView != null) {
            detailRekamMedisView.setVisible(false);
            detailRekamMedisView.setManaged(false);
        }
        if (kelolaTagihanView != null) {
            kelolaTagihanView.setVisible(false);
            kelolaTagihanView.setManaged(false);
        }
        if (lihatTagihanView != null) {
            lihatTagihanView.setVisible(false);
            lihatTagihanView.setManaged(false);
        }
    }

    private void highlightMenuButton(Button activeBtn) {
        Button[] buttons = {btnMenuDashboard, btnMenuVerifikasi, btnMenuPasienOffline, btnMenuKelolaPendaftaran, btnMenuArsipRekamMedis, btnMenuKelolaTagihan};
        for (Button b : buttons) {
            if (b != null) {
                if (b == activeBtn) {
                    b.getStyleClass().remove("sidebar-btn");
                    if (!b.getStyleClass().contains("sidebar-btn-active")) {
                        b.getStyleClass().add("sidebar-btn-active");
                    }
                } else {
                    b.getStyleClass().remove("sidebar-btn-active");
                    if (!b.getStyleClass().contains("sidebar-btn")) {
                        b.getStyleClass().add("sidebar-btn");
                    }
                }
            }
        }
    }

    @FXML
    private void handleMenuDashboard() {
        hideAllViews();
        dashboardView.setVisible(true);
        dashboardView.setManaged(true);
        highlightMenuButton(btnMenuDashboard);
        loadDashboardData();
    }

    @FXML
    private void handleMenuVerifikasi() {
        hideAllViews();
        verifikasiView.setVisible(true);
        verifikasiView.setManaged(true);
        highlightMenuButton(btnMenuVerifikasi);
        loadVerifikasiData();
    }

    @FXML
    private void handleMenuPasienOffline() {
        hideAllViews();
        if (pasienOfflineView != null) {
            pasienOfflineView.setVisible(true);
            pasienOfflineView.setManaged(true);
        }
        highlightMenuButton(btnMenuPasienOffline);
    }

    @FXML
    private void handleMenuKelolaPendaftaran() {
        hideAllViews();
        if (kelolaPendaftaranView != null) {
            kelolaPendaftaranView.setVisible(true);
            kelolaPendaftaranView.setManaged(true);
        }
        highlightMenuButton(btnMenuKelolaPendaftaran);
        loadKelolaData();
    }

    @FXML
    private void handleMenuArsipRekamMedis() {
        hideAllViews();
        if (arsipRekamMedisView != null) {
            arsipRekamMedisView.setVisible(true);
            arsipRekamMedisView.setManaged(true);
        }
        highlightMenuButton(btnMenuArsipRekamMedis);
        loadArsipData();
    }

    @FXML
    private void handleMenuKelolaTagihan() {
        hideAllViews();
        if (kelolaTagihanView != null) {
            kelolaTagihanView.setVisible(true);
            kelolaTagihanView.setManaged(true);
        }
        highlightMenuButton(btnMenuKelolaTagihan);
        loadTagihanData();
    }

    // --- Data Loaders ---
    private void loadDashboardData() {
        dashboardList.clear();
        String sql = "SELECT a.id_antrian, a.no_antrian, p.nama_pasien, a.tanggal_antrian, a.status, a.keluhan, p.no_hp, p.alamat, p.tanggal_lahir, p.jenis_kelamin "
                   + "FROM antrian a "
                   + "JOIN pasien p ON a.id_pasien = p.id_pasien "
                   + "ORDER BY a.tanggal_antrian ASC, a.no_antrian ASC";

        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                dashboardList.add(mapPatient(rs));
            }
            tableView.setItems(dashboardList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadVerifikasiData() {
        verifikasiList.clear();
        String sql = "SELECT a.id_antrian, a.no_antrian, p.nama_pasien, a.tanggal_antrian, a.status, a.keluhan, p.no_hp, p.alamat, p.tanggal_lahir, p.jenis_kelamin "
                   + "FROM antrian a "
                   + "JOIN pasien p ON a.id_pasien = p.id_pasien "
                   + "ORDER BY a.tanggal_antrian ASC, a.no_antrian ASC";

        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                verifikasiList.add(mapPatient(rs));
            }
            filterVerifikasiData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Patient mapPatient(ResultSet rs) throws Exception {
        int idAntrian = rs.getInt("id_antrian");
        int no = rs.getInt("no_antrian");
        String nama = rs.getString("nama_pasien");
        LocalDate tanggal = rs.getDate("tanggal_antrian").toLocalDate();
        String status = rs.getString("status");
        String keluhan = rs.getString("keluhan");
        String noHp = rs.getString("no_hp");
        String alamat = rs.getString("alamat");
        
        LocalDate tglLahir = null;
        if (rs.getDate("tanggal_lahir") != null) {
            tglLahir = rs.getDate("tanggal_lahir").toLocalDate();
        }
        
        String jenisKelamin = rs.getString("jenis_kelamin");

        return new Patient(idAntrian, no, nama, tanggal, status, keluhan, noHp, alamat, tglLahir, jenisKelamin);
    }

    // --- Search & Filter Logic ---
    private void filterVerifikasiData() {
        String filterStatus = statusFilterComboBox.getValue();
        String searchQuery = searchField.getText().toLowerCase().trim();

        ObservableList<Patient> filtered = FXCollections.observableArrayList();

        for (Patient p : verifikasiList) {
            // Filter Status
            boolean matchesStatus = "Semua status".equals(filterStatus) || p.getStatus().equalsIgnoreCase(filterStatus);
            
            // Filter Search (Nama / No HP)
            boolean matchesSearch = searchQuery.isEmpty() 
                    || p.getNamaPasien().toLowerCase().contains(searchQuery)
                    || (p.getNoHp() != null && p.getNoHp().contains(searchQuery));

            if (matchesStatus && matchesSearch) {
                filtered.add(p);
            }
        }
        verifikasiTable.setItems(filtered);
    }

    // --- Verifikasi Aksi Handlers ---
    private void handleVerifyAction(Patient patient) {
        selectedPatientForVerification = patient;
        confirmActionOverlay.setVisible(true);
        confirmActionOverlay.setManaged(true);
    }

    @FXML
    private void handleConfirmYes() {
        confirmActionOverlay.setVisible(false);
        confirmActionOverlay.setManaged(false);

        if (selectedPatientForVerification != null) {
            // 1. Tampilkan Loading Spinner
            loadingOverlay.setVisible(true);
            loadingOverlay.setManaged(true);

            // 2. Transisi loading (1.2 detik)
            PauseTransition loadingPause = new PauseTransition(Duration.seconds(1.2));
            loadingPause.setOnFinished(event -> {
                // Update ke database
                String sql = "UPDATE antrian SET status = 'Diverifikasi' WHERE id_antrian = ?";
                try (Connection conn = Database.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, selectedPatientForVerification.getIdAntrian());
                    pstmt.executeUpdate();
                    System.out.println("Status antrean pasien ID " + selectedPatientForVerification.getIdAntrian() + " berhasil diverifikasi.");
                } catch (Exception e) {
                    showErrorAlert("Gagal memverifikasi antrean", e);
                }

                // Sembunyikan loading
                loadingOverlay.setVisible(false);
                loadingOverlay.setManaged(false);

                // 3. Tampilkan Success popup (1.2 detik)
                successOverlay.setVisible(true);
                successOverlay.setManaged(true);

                PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
                successPause.setOnFinished(successEvent -> {
                    successOverlay.setVisible(false);
                    successOverlay.setManaged(false);
                    
                    // Refresh data tabel
                    loadVerifikasiData();
                });
                successPause.play();
            });
            loadingPause.play();
        }
    }

    @FXML
    private void handleConfirmNo() {
        confirmActionOverlay.setVisible(false);
        confirmActionOverlay.setManaged(false);
        selectedPatientForVerification = null;
    }

    // --- Detail View Handlers ---
    private void handleViewAction(Patient patient) {
        // Isi text field detail
        detailNamaField.setText(patient.getNamaPasien());
        
        // Mock NIK karena dihapus dari database
        detailNikField.setText("3201234567890001");
        
        detailAlamatField.setText(patient.getAlamat() != null ? patient.getAlamat() : "");
        detailTglLahirField.setText(patient.getTanggalLahir() != null ? patient.getTanggalLahir().toString() : "");
        detailKeluhanArea.setText(patient.getKeluhan() != null ? patient.getKeluhan() : "");

        // Pindah tampilan ke panel detail
        verifikasiView.setVisible(false);
        verifikasiView.setManaged(false);
        detailView.setVisible(true);
        detailView.setManaged(true);
    }

    @FXML
    private void handleBackFromDetail() {
        // Kembali ke tabel verifikasi
        detailView.setVisible(false);
        detailView.setManaged(false);
        verifikasiView.setVisible(true);
        verifikasiView.setManaged(true);
    }

    // --- Logout Dialog Handlers ---
    @FXML
    private void showLogoutModal() {
        logoutOverlay.setVisible(true);
        logoutOverlay.setManaged(true);
    }

    @FXML
    private void handleLogoutYes() throws IOException {
        App.setRoot("primary");
    }

    @FXML
    private void handleLogoutNo() {
        logoutOverlay.setVisible(false);
        logoutOverlay.setManaged(false);
    }

    // --- Kelola & Arsip Data Loaders & Logic ---
    private void loadKelolaData() {
        kelolaList.clear();
        String sql = "SELECT a.id_antrian, a.no_antrian, p.nama_pasien, a.tanggal_antrian, a.status, a.keluhan, p.no_hp, p.alamat, p.tanggal_lahir, p.jenis_kelamin "
                   + "FROM antrian a "
                   + "JOIN pasien p ON a.id_pasien = p.id_pasien "
                   + "ORDER BY a.tanggal_antrian ASC, a.no_antrian ASC";

        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                kelolaList.add(mapPatient(rs));
            }
            filterKelolaData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterKelolaData() {
        if (kelolaStatusComboBox == null) return;
        String filterStatus = kelolaStatusComboBox.getValue();
        LocalDate dariTgl = kelolaDariDatePicker.getValue();
        LocalDate sampaiTgl = kelolaSampaiDatePicker.getValue();

        ObservableList<Patient> filtered = FXCollections.observableArrayList();

        for (Patient p : kelolaList) {
            boolean matchesStatus = "Semua status".equals(filterStatus) || p.getStatus().equalsIgnoreCase(filterStatus);
            
            boolean matchesDari = (dariTgl == null) || !p.getTanggalDaftar().isBefore(dariTgl);
            boolean matchesSampai = (sampaiTgl == null) || !p.getTanggalDaftar().isAfter(sampaiTgl);

            if (matchesStatus && matchesDari && matchesSampai) {
                filtered.add(p);
            }
        }
        kelolaTable.setItems(filtered);
    }

    private void loadArsipData() {
        arsipList.clear();
        String sql = "SELECT rm.id_rekam_medis, rm.id_pasien, p.nama_pasien, p.jenis_kelamin, p.no_hp, p.tanggal_lahir, p.alamat, "
                   + "       rm.tanggal AS tanggal_berobat, rm.diagnosa, rm.keluhan, rm.tindakan, rm.catatan, "
                   + "       a.no_antrian, a.id_antrian "
                   + "FROM rekam_medis rm "
                   + "JOIN pasien p ON rm.id_pasien = p.id_pasien "
                   + "LEFT JOIN pemeriksaan pem ON rm.id_pemeriksaan = pem.id_pemeriksaan "
                   + "LEFT JOIN antrian a ON pem.id_antrian = a.id_antrian "
                   + "ORDER BY rm.tanggal DESC";

        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            int count = 1;
            while (rs.next()) {
                int idAntrian = rs.getInt("id_antrian");
                int noAntrian = rs.getInt("no_antrian");
                int idPasien = rs.getInt("id_pasien");
                String nama = rs.getString("nama_pasien");
                LocalDate tglBerobat = rs.getDate("tanggal_berobat").toLocalDate();
                String keluhan = rs.getString("keluhan");
                String alamat = rs.getString("alamat");
                LocalDate tglLahir = rs.getDate("tanggal_lahir") != null ? rs.getDate("tanggal_lahir").toLocalDate() : null;
                String jk = rs.getString("jenis_kelamin");
                
                Patient patient = new Patient(idAntrian, count++, nama, tglBerobat, "Diverifikasi", keluhan, rs.getString("no_hp"), alamat, tglLahir, jk);
                patient.setNoRm(String.format("RM %03d", idPasien));
                patient.setDiagnosa(rs.getString("diagnosa"));
                patient.setTindakan(rs.getString("tindakan"));
                patient.setCatatan(rs.getString("catatan"));
                patient.setNo(noAntrian);
                
                arsipList.add(patient);
            }
            filterArsipData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterArsipData() {
        if (arsipSearchField == null) return;
        String query = arsipSearchField.getText().toLowerCase().trim();
        LocalDate dariTgl = arsipDariDatePicker.getValue();
        LocalDate sampaiTgl = arsipSampaiDatePicker.getValue();

        ObservableList<Patient> filtered = FXCollections.observableArrayList();
        int displayNo = 1;

        for (Patient p : arsipList) {
            boolean matchesSearch = query.isEmpty() 
                    || p.getNamaPasien().toLowerCase().contains(query)
                    || (p.getNoRm() != null && p.getNoRm().toLowerCase().contains(query));
            
            boolean matchesDari = (dariTgl == null) || !p.getTanggalDaftar().isBefore(dariTgl);
            boolean matchesSampai = (sampaiTgl == null) || !p.getTanggalDaftar().isAfter(sampaiTgl);

            if (matchesSearch && matchesDari && matchesSampai) {
                Patient viewItem = new Patient(p.getIdAntrian(), displayNo++, p.getNamaPasien(), p.getTanggalDaftar(), p.getStatus(), p.getKeluhan(), p.getNoHp(), p.getAlamat(), p.getTanggalLahir(), p.getJenisKelamin());
                viewItem.setNoRm(p.getNoRm());
                viewItem.setDiagnosa(p.getDiagnosa());
                viewItem.setTindakan(p.getTindakan());
                viewItem.setCatatan(p.getCatatan());
                viewItem.setNo(p.getNo());
                filtered.add(viewItem);
            }
        }
        arsipTable.setItems(filtered);
    }

    private void handleViewRekamMedis(Patient patient) {
        hideAllViews();
        if (detailRekamMedisView != null) {
            detailRekamMedisView.setVisible(true);
            detailRekamMedisView.setManaged(true);
        }

        rmDetailNama.setText(patient.getNamaPasien());
        rmDetailNik.setText("320" + String.format("%013d", patient.getIdAntrian() > 0 ? patient.getIdAntrian() : 1));
        rmDetailAlamat.setText(patient.getAlamat() != null ? patient.getAlamat() : "");
        rmDetailTglLahir.setText(patient.getTanggalLahir() != null ? patient.getTanggalLahir().toString() : "");
        rmDetailJk.setText(patient.getJenisKelamin() != null ? patient.getJenisKelamin() : "");
        rmDetailNoAntrian.setText(String.valueOf(patient.getNo()));
        rmDetailRiwayatKunjungan.setText(patient.getTanggalDaftar() != null ? patient.getTanggalDaftar().toString() : "");
        rmDetailDiagnosa.setText(patient.getDiagnosa() != null ? patient.getDiagnosa() : "");
    }

    @FXML
    private void handleBackFromRmDetail() {
        hideAllViews();
        if (arsipRekamMedisView != null) {
            arsipRekamMedisView.setVisible(true);
            arsipRekamMedisView.setManaged(true);
        }
    }

    // --- Pasien Offline Registration Handlers ---
    @FXML
    private void handleRegisterOffline() {
        String nama = offlineNamaField.getText().trim();
        LocalDate tglLahirVal = offlineTglLahirDatePicker.getValue();
        String jk = offlineJkComboBox.getValue();
        String nik = offlineNikField.getText().trim();
        String noHp = offlineNoHpField.getText().trim();
        String alamat = offlineAlamatField.getText().trim();
        String tglDaftarStr = offlineTglDaftarField.getText().trim();
        String keluhan = offlineKeluhanArea.getText() != null ? offlineKeluhanArea.getText().trim() : "";

        if (nama.isEmpty() || tglLahirVal == null || jk == null || jk.isEmpty() 
            || nik.isEmpty() || noHp.isEmpty() || alamat.isEmpty() || tglDaftarStr.isEmpty() || keluhan.isEmpty()) {
            showAlert("Validasi Gagal", "Harap isi semua field input termasuk Keluhan.");
            return;
        }

        try {
            LocalDate.parse(tglDaftarStr);
        } catch (Exception e) {
            showAlert("Validasi Gagal", "Format Tanggal Daftar salah. Gunakan YYYY-MM-DD.");
            return;
        }

        confirmOfflineOverlay.setVisible(true);
        confirmOfflineOverlay.setManaged(true);
    }

    @FXML
    private void handleConfirmOfflineNo() {
        confirmOfflineOverlay.setVisible(false);
        confirmOfflineOverlay.setManaged(false);
    }

    @FXML
    private void handleConfirmOfflineYes() {
        confirmOfflineOverlay.setVisible(false);
        confirmOfflineOverlay.setManaged(false);

        loadingOverlay.setVisible(true);
        loadingOverlay.setManaged(true);

        PauseTransition loadingPause = new PauseTransition(Duration.seconds(1.2));
        loadingPause.setOnFinished(event -> {
            String nama = offlineNamaField.getText().trim();
            LocalDate tglLahirVal = offlineTglLahirDatePicker.getValue();
            String jk = offlineJkComboBox.getValue();
            String noHp = offlineNoHpField.getText().trim();
            String alamat = offlineAlamatField.getText().trim();
            String tglDaftarStr = offlineTglDaftarField.getText().trim();
            String keluhan = offlineKeluhanArea.getText() != null ? offlineKeluhanArea.getText().trim() : "Pendaftaran offline oleh admin";

            Connection conn = null;
            try {
                conn = Database.getConnection();
                conn.setAutoCommit(false);

                // 1. Insert user
                String username = (nama.toLowerCase().replaceAll("\\s+", "") + "_" + (noHp.length() > 4 ? noHp.substring(noHp.length() - 4) : noHp));
                String insertUserSql = "INSERT INTO user (username, password, id_role) VALUES (?, ?, 3)";
                int userId = -1;
                try (PreparedStatement psUser = conn.prepareStatement(insertUserSql, Statement.RETURN_GENERATED_KEYS)) {
                    psUser.setString(1, username);
                    psUser.setString(2, "pasien");
                    psUser.executeUpdate();
                    try (ResultSet rsKeys = psUser.getGeneratedKeys()) {
                        if (rsKeys.next()) {
                            userId = rsKeys.getInt(1);
                        }
                    }
                }

                if (userId == -1) {
                    throw new SQLException("Gagal membuat user baru.");
                }

                // 2. Insert pasien
                String insertPasienSql = "INSERT INTO pasien (id_user, nama_pasien, jenis_kelamin, no_hp, tanggal_lahir, alamat) VALUES (?, ?, ?, ?, ?, ?)";
                int pasienId = -1;
                try (PreparedStatement psPasien = conn.prepareStatement(insertPasienSql, Statement.RETURN_GENERATED_KEYS)) {
                    psPasien.setInt(1, userId);
                    psPasien.setString(2, nama);
                    psPasien.setString(3, jk);
                    psPasien.setString(4, noHp);
                    psPasien.setDate(5, java.sql.Date.valueOf(tglLahirVal));
                    psPasien.setString(6, alamat);
                    psPasien.executeUpdate();
                    try (ResultSet rsKeys = psPasien.getGeneratedKeys()) {
                        if (rsKeys.next()) {
                            pasienId = rsKeys.getInt(1);
                        }
                    }
                }

                if (pasienId == -1) {
                    throw new SQLException("Gagal mendaftarkan data diri pasien.");
                }

                // 3. Update user
                String updateUserSql = "UPDATE user SET id_pasien = ? WHERE id_user = ?";
                try (PreparedStatement psUpdateUser = conn.prepareStatement(updateUserSql)) {
                    psUpdateUser.setInt(1, pasienId);
                    psUpdateUser.setInt(2, userId);
                    psUpdateUser.executeUpdate();
                }

                // 4. Hitung nomor antrean berikutnya
                String countQueueSql = "SELECT COALESCE(MAX(no_antrian), 0) + 1 FROM antrian WHERE tanggal_antrian = ?";
                int nextQueueNo = 1;
                try (PreparedStatement psCount = conn.prepareStatement(countQueueSql)) {
                    psCount.setDate(1, java.sql.Date.valueOf(LocalDate.parse(tglDaftarStr)));
                    try (ResultSet rsCount = psCount.executeQuery()) {
                        if (rsCount.next()) {
                            nextQueueNo = rsCount.getInt(1);
                        }
                    }
                }

                // 5. Insert antrian
                String insertAntrianSql = "INSERT INTO antrian (id_pasien, id_dokter, tanggal_antrian, no_antrian, status, keluhan) VALUES (?, 1, ?, ?, 'Menunggu Verifikasi', ?)";
                try (PreparedStatement psAntrian = conn.prepareStatement(insertAntrianSql)) {
                    psAntrian.setInt(1, pasienId);
                    psAntrian.setDate(2, java.sql.Date.valueOf(LocalDate.parse(tglDaftarStr)));
                    psAntrian.setInt(3, nextQueueNo);
                    psAntrian.setString(4, keluhan);
                    psAntrian.executeUpdate();
                }

                conn.commit();

                loadingOverlay.setVisible(false);
                loadingOverlay.setManaged(false);

                successOfflineOverlay.setVisible(true);
                successOfflineOverlay.setManaged(true);

                PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
                successPause.setOnFinished(successEvent -> {
                    successOfflineOverlay.setVisible(false);
                    successOfflineOverlay.setManaged(false);

                    offlineNamaField.clear();
                    offlineTglLahirDatePicker.setValue(null);
                    offlineNikField.clear();
                    offlineNoHpField.clear();
                    offlineAlamatField.clear();
                    offlineTglDaftarField.setText(LocalDate.now().toString());
                    offlineJkComboBox.setValue("Laki-laki");
                    if (offlineKeluhanArea != null) offlineKeluhanArea.clear();

                    handleMenuDashboard();
                });
                successPause.play();

            } catch (Exception e) {
                if (conn != null) {
                    try {
                        conn.rollback();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
                e.printStackTrace();
                loadingOverlay.setVisible(false);
                loadingOverlay.setManaged(false);
                showAlert("Kesalahan Database", "Gagal menyimpan pendaftaran offline: " + e.getMessage());
            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        loadingPause.play();
    }

    // --- Billing (Kelola Tagihan) Logic ---
    private void loadTagihanData() {
        tagihanList.clear();
        String sql = "SELECT t.id_tagihan, t.id_pasien, t.id_antrian, t.biaya_pemeriksaan, t.biaya_admin, t.total_tagihan, t.status AS status_tagihan, t.tanggal AS tanggal_tagihan, "
                   + "       p.nama_pasien, p.jenis_kelamin, p.no_hp, p.alamat, p.tanggal_lahir, "
                   + "       a.no_antrian, a.status AS status_antrian "
                   + "FROM tagihan t "
                   + "JOIN pasien p ON t.id_pasien = p.id_pasien "
                   + "LEFT JOIN antrian a ON t.id_antrian = a.id_antrian "
                   + "ORDER BY t.tanggal DESC, t.id_tagihan DESC";

        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            int count = 1;
            while (rs.next()) {
                int idAntrian = rs.getInt("id_antrian");
                int noAntrian = rs.getInt("no_antrian");
                String nama = rs.getString("nama_pasien");
                LocalDate tglTagihan = rs.getDate("tanggal_tagihan").toLocalDate();
                String statusTagihan = rs.getString("status_tagihan");
                String jk = rs.getString("jenis_kelamin");
                String noHp = rs.getString("no_hp");
                String alamat = rs.getString("alamat");
                LocalDate tglLahir = rs.getDate("tanggal_lahir") != null ? rs.getDate("tanggal_lahir").toLocalDate() : null;
                
                double biayaPemeriksaan = rs.getDouble("biaya_pemeriksaan");
                double biayaAdmin = rs.getDouble("biaya_admin");
                double totalTagihan = rs.getDouble("total_tagihan");

                Patient patient = new Patient(idAntrian, count++, nama, tglTagihan, rs.getString("status_antrian"), "Tagihan", noHp, alamat, tglLahir, jk);
                patient.setIdTagihan(rs.getInt("id_tagihan"));
                patient.setNoTagihan(String.format("TG-%03d", rs.getInt("id_tagihan")));
                patient.setBiayaPemeriksaan(biayaPemeriksaan);
                patient.setBiayaAdmin(biayaAdmin);
                patient.setTotalTagihan(totalTagihan);
                patient.setStatusTagihan(statusTagihan);
                
                tagihanList.add(patient);
            }
            filterTagihanData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterTagihanData() {
        if (kelolaTagihanStatusComboBox == null) return;
        String filterStatus = kelolaTagihanStatusComboBox.getValue();
        LocalDate dariTgl = kelolaTagihanDariDatePicker.getValue();
        LocalDate sampaiTgl = kelolaTagihanSampaiDatePicker.getValue();
        String query = kelolaTagihanSearchField.getText().toLowerCase().trim();

        ObservableList<Patient> filtered = FXCollections.observableArrayList();
        int displayNo = 1;

        for (Patient p : tagihanList) {
            boolean matchesStatus = "Semua status".equals(filterStatus) || p.getStatusTagihan().equalsIgnoreCase(filterStatus);
            
            boolean matchesDari = (dariTgl == null) || !p.getTanggalDaftar().isBefore(dariTgl);
            boolean matchesSampai = (sampaiTgl == null) || !p.getTanggalDaftar().isAfter(sampaiTgl);
            
            boolean matchesSearch = query.isEmpty() 
                    || p.getNamaPasien().toLowerCase().contains(query)
                    || p.getNoTagihan().toLowerCase().contains(query);

            if (matchesStatus && matchesDari && matchesSampai && matchesSearch) {
                Patient viewItem = new Patient(p.getIdAntrian(), displayNo++, p.getNamaPasien(), p.getTanggalDaftar(), p.getStatus(), p.getKeluhan(), p.getNoHp(), p.getAlamat(), p.getTanggalLahir(), p.getJenisKelamin());
                viewItem.setIdTagihan(p.getIdTagihan());
                viewItem.setNoTagihan(p.getNoTagihan());
                viewItem.setBiayaPemeriksaan(p.getBiayaPemeriksaan());
                viewItem.setBiayaAdmin(p.getBiayaAdmin());
                viewItem.setTotalTagihan(p.getTotalTagihan());
                viewItem.setStatusTagihan(p.getStatusTagihan());
                filtered.add(viewItem);
            }
        }
        kelolaTagihanTable.setItems(filtered);
    }

    private void handleViewTagihan(Patient patient) {
        billDetailPemeriksaan.setText(formatRupiah(patient.getBiayaPemeriksaan()));
        billDetailAdmin.setText(formatRupiah(patient.getBiayaAdmin()));
        billDetailTotal.setText(formatRupiah(patient.getTotalTagihan()));
        billDetailStatus.setText(patient.getStatusTagihan());

        hideAllViews();
        lihatTagihanView.setVisible(true);
        lihatTagihanView.setManaged(true);
    }

    @FXML
    private void handleBackFromBillDetail() {
        lihatTagihanView.setVisible(false);
        lihatTagihanView.setManaged(false);
        kelolaTagihanView.setVisible(true);
        kelolaTagihanView.setManaged(true);
    }

    private void handlePayTagihan(Patient patient) {
        selectedPatientForPayment = patient;
        payNamaPasien.setText(patient.getNamaPasien());
        payTotalTagihan.setText(formatRupiah(patient.getTotalTagihan()));

        bayarOverlay.setVisible(true);
        bayarOverlay.setManaged(true);
    }

    @FXML
    private void handleCloseBayarOverlay() {
        bayarOverlay.setVisible(false);
        bayarOverlay.setManaged(false);
        selectedPatientForPayment = null;
    }

    @FXML
    private void handleChooseTunai() {
        bayarOverlay.setVisible(false);
        bayarOverlay.setManaged(false);

        if (selectedPatientForPayment != null) {
            cashTotalTagihan.setText(formatRupiah(selectedPatientForPayment.getTotalTagihan()));
            cashUangDiterima.clear();
            cashKembalian.setText("Rp 0");

            tunaiOverlay.setVisible(true);
            tunaiOverlay.setManaged(true);
        }
    }

    @FXML
    private void handleCancelCash() {
        tunaiOverlay.setVisible(false);
        tunaiOverlay.setManaged(false);

        // Re-open bayar choice modal
        bayarOverlay.setVisible(true);
        bayarOverlay.setManaged(true);
    }

    @FXML
    private void handleChooseQris() {
        bayarOverlay.setVisible(false);
        bayarOverlay.setManaged(false);

        if (selectedPatientForPayment != null) {
            try {
                qrisImageView.setImage(new Image(App.class.getResourceAsStream("qris_klinikku.png")));
            } catch (Exception e) {
                System.err.println("Gagal memuat qris_klinikku.png: " + e.getMessage());
            }

            qrisOverlay.setVisible(true);
            qrisOverlay.setManaged(true);
        }
    }

    @FXML
    private void handleCompleteCash() {
        if (selectedPatientForPayment == null) return;
        
        String text = cashUangDiterima.getText().replaceAll("[^\\d]", "");
        if (text.isEmpty()) {
            showAlert("Validasi Pembayaran", "Harap masukkan jumlah uang diterima.");
            return;
        }
        double received = Double.parseDouble(text);
        if (received < selectedPatientForPayment.getTotalTagihan()) {
            showAlert("Validasi Pembayaran", "Uang diterima kurang dari total tagihan.");
            return;
        }

        tunaiOverlay.setVisible(false);
        tunaiOverlay.setManaged(false);

        processPaymentSuccess();
    }

    @FXML
    private void handleCompleteQris() {
        qrisOverlay.setVisible(false);
        qrisOverlay.setManaged(false);

        processPaymentSuccess();
    }

    private void processPaymentSuccess() {
        if (selectedPatientForPayment == null) return;

        // 1. Show Loading Overlay
        loadingOverlay.setVisible(true);
        loadingOverlay.setManaged(true);

        // 2. Loading transition 1.2s
        PauseTransition loadingPause = new PauseTransition(Duration.seconds(1.2));
        loadingPause.setOnFinished(event -> {
            String sql = "UPDATE tagihan SET status = 'Lunas' WHERE id_tagihan = ?";
            try (Connection conn = Database.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, selectedPatientForPayment.getIdTagihan());
                pstmt.executeUpdate();
                System.out.println("Status tagihan ID " + selectedPatientForPayment.getIdTagihan() + " berhasil diupdate ke Lunas.");
            } catch (Exception e) {
                System.err.println("Gagal mengupdate status tagihan: " + e.getMessage());
                e.printStackTrace();
            }

            // Hide loading
            loadingOverlay.setVisible(false);
            loadingOverlay.setManaged(false);

            // 3. Show Success Overlay 1.2s
            successOverlay.setVisible(true);
            successOverlay.setManaged(true);

            PauseTransition successPause = new PauseTransition(Duration.seconds(1.2));
            successPause.setOnFinished(successEvent -> {
                successOverlay.setVisible(false);
                successOverlay.setManaged(false);

                // Reset selected patient
                selectedPatientForPayment = null;

                // Refresh tables
                loadTagihanData();
            });
            successPause.play();
        });
        loadingPause.play();
    }

    private String formatRupiah(double value) {
        return String.format("Rp %,.0f", value).replace(',', '.');
    }

    private void showAlert(String title, String content) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void showErrorAlert(String header, Exception e) {
        javafx.application.Platform.runLater(() -> {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Terjadi Kesalahan Server");
            alert.setHeaderText(header);
            alert.setContentText("Detail Error: " + (e != null ? e.getMessage() : "Kesalahan Tidak Diketahui"));
            alert.showAndWait();
        });
    }
}
