package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PilihJadwalPasienController implements Initializable {

    @FXML private DatePicker tglField;
    @FXML private TextField jamField;
    @FXML private Label errorLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tglField.setValue(LocalDate.now());
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DetailDokterPasien");
    }

    @FXML
    private void booking() {
        LocalDate tgl = tglField.getValue();
        String jamStr = jamField.getText().trim();
        
        if (tgl == null || jamStr.isEmpty()) {
            showError("Tanggal dan Jam wajib diisi.");
            return;
        }

        // Parse jam
        LocalTime jamPilih = null;
        try {
            // Bisa menerima format 13.20 atau 13:20
            jamStr = jamStr.replace('.', ':');
            if (jamStr.length() == 4) jamStr = "0" + jamStr; // 8:00 -> 08:00
            jamPilih = LocalTime.parse(jamStr);
        } catch (DateTimeParseException e) {
            showError("Format jam salah. Gunakan HH:mm (contoh: 13:20).");
            return;
        }

        // Cek hari praktik sesuai desain Figma
        DayOfWeek day = tgl.getDayOfWeek();
        LocalTime startShift;
        LocalTime endShift;

        if (day == DayOfWeek.MONDAY || day == DayOfWeek.WEDNESDAY) {
            startShift = LocalTime.of(8, 0);
            endShift = LocalTime.of(11, 0);
        } else if (day == DayOfWeek.TUESDAY || day == DayOfWeek.THURSDAY || day == DayOfWeek.FRIDAY) {
            startShift = LocalTime.of(13, 0);
            endShift = LocalTime.of(17, 0);
        } else {
            showError("Dokter libur/tidak praktik pada hari ini.");
            return;
        }

        // Cek apakah jam yang diketik ada di dalam shift
        if (jamPilih.isBefore(startShift) || jamPilih.isAfter(endShift)) {
            showError("Jam di luar jadwal praktik dokter (" + startShift + " - " + endShift + ").");
            return;
        }

        // Aturan: booking minimal 1 jam sebelum pemeriksaan (jika hari ini)
        if (tgl.isEqual(LocalDate.now())) {
            if (LocalTime.now().plusHours(1).isAfter(jamPilih)) {
                showError("Batas waktu booking sudah terlewat (H-1 Jam).");
                return;
            }
        } else if (tgl.isBefore(LocalDate.now())) {
            showError("Tidak dapat mem-booking untuk tanggal yang sudah lewat.");
            return;
        }

        int userId = App.getLoggedInUserId();
        int dokterId = App.getSelectedDokterId();

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showError("Gagal koneksi ke database.");
                return;
            }

            int idPasien = 0;
            String sqlPasien = "SELECT id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasien)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPasien = rs.getInt("id_pasien");
                    }
                }
            }

            if (idPasien == 0) {
                showError("Data pasien tidak ditemukan!");
                return;
            }

            int noAntrianBaru = 1;
            String sqlCekAntrian = "SELECT MAX(no_antrian) FROM antrian WHERE tanggal_antrian = ? AND id_dokter = ?";
            try (PreparedStatement psCek = conn.prepareStatement(sqlCekAntrian)) {
                psCek.setString(1, tgl.toString());
                psCek.setInt(2, dokterId);
                try (ResultSet rsCek = psCek.executeQuery()) {
                    if (rsCek.next()) {
                        noAntrianBaru = rsCek.getInt(1) + 1;
                    }
                }
            }

            String sqlInsert = "INSERT INTO antrian (id_pasien, id_dokter, tanggal_antrian, no_antrian, status) VALUES (?, ?, ?, ?, 'menunggu')";
            try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                psInsert.setInt(1, idPasien);
                psInsert.setInt(2, dokterId);
                psInsert.setString(3, tgl.toString());
                psInsert.setInt(4, noAntrianBaru);
                psInsert.executeUpdate();
            }

            App.setBookingTanggal(tgl.toString());
            App.setBookingJam(jamStr);
            App.setBookingNoAntrian(noAntrianBaru);

            App.setRoot("BookingSuccessPasien");

        } catch (Exception e) {
            e.printStackTrace();
            showError("Terjadi kesalahan saat menyimpan antrean.");
        }
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }
}
