package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

public class EditProfilPasienController implements Initializable {

    @FXML private TextField namaField;
    @FXML private DatePicker tglLahirField;
    @FXML private TextField hpField;
    @FXML private ComboBox<String> genderField;
    @FXML private TextField alamatField;
    @FXML private TextField nikField;
    @FXML private Label messageLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        genderField.getItems().addAll("Laki-laki", "Perempuan");
        loadDataProfil();
    }

    private void loadDataProfil() {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showMessage("Gagal koneksi ke database", false);
                return;
            }

            String sql = "SELECT nama_pasien, tanggal_lahir, no_hp, jenis_kelamin, alamat FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        namaField.setText(rs.getString("nama_pasien"));
                        
                        String tglLahir = rs.getString("tanggal_lahir");
                        if (tglLahir != null && !tglLahir.isEmpty()) {
                            tglLahirField.setValue(LocalDate.parse(tglLahir));
                        }
                        
                        hpField.setText(rs.getString("no_hp"));
                        genderField.setValue(rs.getString("jenis_kelamin"));
                        alamatField.setText(rs.getString("alamat"));
                        nikField.setText(""); // NIK sudah paten / tidak tersimpan di DB saat ini
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showMessage("Terjadi kesalahan saat memuat data", false);
        }
    }

    @FXML
    private void simpanData() {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) {
                showMessage("Gagal koneksi ke database", false);
                return;
            }

            String sql = "UPDATE pasien SET nama_pasien = ?, tanggal_lahir = ?, no_hp = ?, jenis_kelamin = ?, alamat = ? WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, namaField.getText());
                ps.setString(2, tglLahirField.getValue() != null ? tglLahirField.getValue().toString() : "");
                ps.setString(3, hpField.getText());
                ps.setString(4, genderField.getValue() != null ? genderField.getValue() : "");
                ps.setString(5, alamatField.getText());
                ps.setInt(6, userId);
                
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    // Berhasil disimpan, kembali ke Dashboard
                    App.setRoot("DashboardPasien");
                } else {
                    showMessage("Gagal menyimpan data.", false);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showMessage("Terjadi kesalahan saat menyimpan data.", false);
        }
    }

    private void showMessage(String msg, boolean isSuccess) {
        messageLabel.setText(msg);
        messageLabel.setTextFill(isSuccess ? Color.web("#27ae60") : Color.RED);
        messageLabel.setVisible(true);
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("ProfilPasien");
    }
}
