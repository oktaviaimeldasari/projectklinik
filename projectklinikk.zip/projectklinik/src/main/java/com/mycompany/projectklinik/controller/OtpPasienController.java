package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class OtpPasienController implements Initializable {

    @FXML private Label subtitleLabel;
    @FXML private TextField otp1;
    @FXML private TextField otp2;
    @FXML private TextField otp3;
    @FXML private TextField otp4;
    @FXML private Label errorLabel;
    @FXML private Label countdownLabel;

    private int secondsRemaining = 59;
    private Timeline timeline;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String phone = App.getResetPhone();
        if (phone != null && phone.length() >= 4) {
            String obfuscated = phone.substring(0, 2) + "********" + phone.substring(phone.length() - 2);
            subtitleLabel.setText(obfuscated);
        }
        
        // Setup batas 1 angka & auto-focus
        setupOtpField(otp1, otp2);
        setupOtpField(otp2, otp3);
        setupOtpField(otp3, otp4);
        setupOtpField(otp4, null);

        // Mulai timer hitung mundur
        startTimer();
    }

    private void setupOtpField(TextField current, TextField next) {
        current.textProperty().addListener((observable, oldValue, newValue) -> {
            // Hanya izinkan angka
            if (!newValue.matches("\\d*")) {
                current.setText(newValue.replaceAll("[^\\d]", ""));
            }
            // Batasi panjang string jadi 1
            if (current.getText().length() > 1) {
                current.setText(current.getText().substring(0, 1));
            }
            
            // Pindah fokus ke kotak berikutnya jika sudah diketik 1 karakter
            if (current.getText().length() == 1 && next != null) {
                next.requestFocus();
            }
        });
    }

    private void startTimer() {
        if (timeline != null) {
            timeline.stop();
        }
        secondsRemaining = 59;
        updateTimerLabel();
        
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            secondsRemaining--;
            updateTimerLabel();
            if (secondsRemaining <= 0) {
                timeline.stop();
                countdownLabel.setText("Waktu OTP habis. Silakan kirim ulang.");
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void updateTimerLabel() {
        String secStr = secondsRemaining < 10 ? "0" + secondsRemaining : String.valueOf(secondsRemaining);
        countdownLabel.setText("Sisa waktu OTP: 00:" + secStr);
    }

    @FXML
    private void goBack() throws IOException {
        if (timeline != null) timeline.stop();
        App.setRoot("LupaSandiPasien");
    }

    @FXML
    private void masukanKode() throws IOException {
        if (secondsRemaining <= 0) {
            showError("Waktu OTP sudah habis!");
            return;
        }

        String inputOtp = otp1.getText().trim() + otp2.getText().trim() + otp3.getText().trim() + otp4.getText().trim();
        if (inputOtp.length() < 4) {
            showError("Masukkan 4 digit kode OTP.");
            return;
        }
        
        String actualOtp = App.getResetOtp();
        if (inputOtp.equals(actualOtp)) {
            if (timeline != null) timeline.stop();
            App.setRoot("ResetSandiPasien");
        } else {
            showError("Kode OTP salah!");
        }
    }

    @FXML
    private void kirimUlangKode() {
        // Simulasi kirim ulang
        String dummyOtp = "5837"; // OTP baru
        App.setResetOtp(dummyOtp);
        System.out.println("OTP Baru untuk " + App.getResetPhone() + " adalah: " + dummyOtp);
        
        errorLabel.setStyle("-fx-text-fill: green;");
        showError("OTP baru telah dikirim.");
         
        // Reset kolom OTP
        otp1.clear(); otp2.clear(); otp3.clear(); otp4.clear();
        otp1.requestFocus();

        // Ulangi timer
        startTimer();

        // Reset warna tulisan error kembali ke merah setelah 3 detik
        new java.util.Timer().schedule(
            new java.util.TimerTask() {
                @Override
                public void run() {
                    javafx.application.Platform.runLater(() -> {
                        errorLabel.setVisible(false);
                        errorLabel.setStyle("-fx-text-fill: RED;");
                    });
                }
            }, 3000
        );
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}
