package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class RiwayatRekamMedisListController implements Initializable {

    @FXML private VBox listContainer;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadRiwayat();
    }

    private void loadRiwayat() {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            // Dapatkan id_pasien
            int idPasien = 0;
            String sqlPasien = "SELECT id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasien)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPasien = rs.getInt("id_pasien");
                    }
                }
            }

            if (idPasien == 0) return;

            String sql = "SELECT rm.id_rekam_medis, p.nama_pasien, rm.tanggal, a.no_antrian, a.id_antrian "
                       + "FROM rekam_medis rm "
                       + "JOIN pasien p ON rm.id_pasien = p.id_pasien "
                       + "JOIN pemeriksaan pem ON rm.id_pemeriksaan = pem.id_pemeriksaan "
                       + "JOIN antrian a ON pem.id_antrian = a.id_antrian "
                       + "WHERE rm.id_pasien = ? ORDER BY rm.tanggal DESC";
            
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idPasien);
                try (ResultSet rs = ps.executeQuery()) {
                    boolean hasData = false;
                    while (rs.next()) {
                        hasData = true;
                        int idRekamMedis = rs.getInt("id_rekam_medis");
                        String nama = rs.getString("nama_pasien");
                        String tanggal = rs.getString("tanggal");
                        int noAntrian = rs.getInt("no_antrian");
                        int idAntrian = rs.getInt("id_antrian");

                        HBox card = createCard(idRekamMedis, idAntrian, nama, tanggal, noAntrian);
                        listContainer.getChildren().add(card);
                    }
                    
                    if (!hasData) {
                        Label emptyLabel = new Label("Belum ada riwayat rekam medis.");
                        emptyLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #555555;");
                        listContainer.getChildren().add(emptyLabel);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private HBox createCard(int idRekamMedis, int idAntrian, String namaPasien, String tanggal, int noAntrian) {
        HBox card = new HBox(15);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-border-color: #121212; -fx-border-width: 1.5px; -fx-padding: 15px; -fx-cursor: hand;");
        
        // Icon Silhouette
        Label iconLabel = new Label("👤");
        iconLabel.setStyle("-fx-font-size: 40px; -fx-text-fill: #121212;");
        
        VBox iconBox = new VBox(iconLabel);
        iconBox.setAlignment(Pos.CENTER);
        iconBox.setStyle("-fx-border-color: #121212; -fx-border-width: 1px; -fx-padding: 5px;");
        
        // Text Details
        VBox textVBox = new VBox(5);
        Label namaLabel = new Label(namaPasien);
        namaLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #121212;");
        
        Label antrianLabel = new Label("No. Antrian: " + noAntrian);
        antrianLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #121212;");
        
        Label tanggalLabel = new Label("Terakhir: " + tanggal);
        tanggalLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #121212;");
        
        textVBox.getChildren().addAll(namaLabel, antrianLabel, tanggalLabel);
        
        card.getChildren().addAll(iconBox, textVBox);
        
        // Hover and Click Action
        card.setOnMouseEntered(e -> card.setStyle("-fx-border-color: #27ae60; -fx-border-width: 1.5px; -fx-padding: 15px; -fx-cursor: hand; -fx-background-color: #f0fdf4;"));
        card.setOnMouseExited(e -> card.setStyle("-fx-border-color: #121212; -fx-border-width: 1.5px; -fx-padding: 15px; -fx-cursor: hand; -fx-background-color: transparent;"));
        
        card.setOnMouseClicked(e -> {
            try {
                App.setSelectedRekamMedisId(idRekamMedis);
                App.setSelectedAntrianId(idAntrian);
                App.setSelectedRekamMedisTanggal(tanggal);
                App.setRoot("RiwayatRekamMedisDetail");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        
        return card;
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DashboardPasien");
    }
}
