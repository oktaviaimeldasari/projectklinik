package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class DashboardPasienController implements Initializable {

    @FXML private Label namaLabel;
    @FXML private Label nomorAndaLabel;
    @FXML private Label dokterLabel;
    @FXML private Label jamLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        int userId = App.getLoggedInUserId();
        if (userId <= 0) return;

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            String sqlPasien = "SELECT nama_pasien, id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasien)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String nama = rs.getString("nama_pasien");
                        int idPasien = rs.getInt("id_pasien");
                        // Tampilkan nama pertama saja
                        String firstName = nama.split(" ")[0];
                        namaLabel.setText(firstName);
                        
                        loadAntreanHariIni(conn, idPasien);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAntreanHariIni(Connection conn, int idPasien) {
        String sql = "SELECT a.no_antrian, d.nama_dokter " +
                     "FROM antrian a " +
                     "JOIN dokter d ON a.id_dokter = d.id_dokter " +
                     "WHERE a.id_pasien = ? AND a.tanggal_antrian = CURDATE() " +
                     "ORDER BY a.id_antrian DESC LIMIT 1";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPasien);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int noAntrian = rs.getInt("no_antrian");
                    String namaDokter = rs.getString("nama_dokter");
                    
                    nomorAndaLabel.setText(String.format("%02d", noAntrian));
                    dokterLabel.setText(namaDokter);
                    jamLabel.setText("Sesuai Jadwal");
                } else {
                    nomorAndaLabel.setText("--");
                    dokterLabel.setText("-");
                    jamLabel.setText("-");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void daftarBerobat() throws IOException {
        App.setRoot("DaftarBerobatPasien");
    }

    @FXML
    private void bukaProfil() throws IOException {
        App.setRoot("ProfilPasien");
    }

    @FXML
    private void bukaRiwayat() throws IOException {
        App.setRoot("RiwayatRekamMedisList");
    }

    @FXML
    private void logout() throws IOException {
        App.setLoggedInUserId(0);
        App.setLoggedInUsername(null);
        App.setRoot("LoginPasien");
    }
}
