package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class DetailDokterPasienController implements Initializable {

    @FXML private Label namaLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String nama = App.getSelectedDokterName();
        if (nama != null) {
            namaLabel.setText(nama);
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DaftarBerobatPasien");
    }

    @FXML
    private void booking() throws IOException {
        App.setRoot("PilihJadwalPasien");
    }
}
