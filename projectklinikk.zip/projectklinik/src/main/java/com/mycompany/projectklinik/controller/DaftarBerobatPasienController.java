package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class DaftarBerobatPasienController implements Initializable {

    @FXML private TextField searchField;
    @FXML private VBox dokterContainer;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadDokter("");

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            loadDokter(newValue.trim());
        });
    }

    private void loadDokter(String keyword) {
        dokterContainer.getChildren().clear();

        try (Connection conn = Database.getConnection()) {
            if (conn != null) {
                String sql = "SELECT id_dokter, nama_dokter FROM dokter WHERE nama_dokter LIKE ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, "%" + keyword + "%");
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            int idDokter = rs.getInt("id_dokter");
                            String nama = rs.getString("nama_dokter");
                            
                            // Karena kolom spesialisasi tidak ada di database, kita set statis
                            String spesialis = "Dokter umum";

                            HBox card = createDokterCard(idDokter, nama, spesialis);
                            dokterContainer.getChildren().add(card);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Gagal query database, lanjut gunakan data dummy.");
        }

        // Fallback jika database benar-benar kosong atau koneksi gagal
        if (dokterContainer.getChildren().isEmpty() && keyword.isEmpty()) {
            dokterContainer.getChildren().add(createDokterCard(1, "Dr. Andi", "Dokter umum"));
            dokterContainer.getChildren().add(createDokterCard(2, "Dr. Ayu", "Dokter umum"));
        }
    }

    private HBox createDokterCard(int idDokter, String nama, String spesialis) {
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setSpacing(20.0);
        hbox.setStyle("-fx-border-color: #121212; -fx-border-width: 1px; -fx-border-radius: 8px; -fx-padding: 15px; -fx-cursor: hand;");

        Label iconLabel = new Label("👤");
        iconLabel.setStyle("-fx-font-size: 40px; -fx-text-fill: #121212;");

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER_LEFT);

        Label nameLabel = new Label(nama);
        nameLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #121212;");
        
        Label specLabel = new Label(spesialis);
        specLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #121212;");

        vbox.getChildren().addAll(nameLabel, specLabel);
        hbox.getChildren().addAll(iconLabel, vbox);

        hbox.setOnMouseClicked(e -> {
            try {
                // Simpan ID dokter yang dipilih ke state aplikasi
                App.setSelectedDokterId(idDokter);
                App.setSelectedDokterName(nama);
                App.setRoot("DetailDokterPasien");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        return hbox;
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("DashboardPasien");
    }
}
