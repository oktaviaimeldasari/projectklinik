package com.mycompany.projectklinik.controller;

import java.io.IOException;
import com.mycompany.projectklinik.App;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class WelcomePasienController {

    @FXML
    private void goToLogin() throws IOException {
        App.setRoot("LoginPasien");
    }

    @FXML
    private void goToRegister() throws IOException {
        App.setRoot("RegisterPasien");
    }
    
    @FXML
    private void switchToDesktop(ActionEvent event) throws IOException {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        // Kembalikan ukuran layar untuk Desktop
        stage.setWidth(950);
        stage.setHeight(600);
        stage.centerOnScreen();
        
        // Reset session
        App.setLoggedInUserId(0);
        App.setLoggedInUsername(null);
        
        App.setRoot("primary");
    }
}
