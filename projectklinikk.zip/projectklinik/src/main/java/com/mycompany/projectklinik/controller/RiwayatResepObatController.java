package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import com.mycompany.projectklinik.database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class RiwayatResepObatController implements Initializable {

    @FXML private Label tanggalLabel;
    @FXML private Label namaDokterLabel;
    @FXML private Label namaPasienLabel;
    @FXML private Label tglLahirLabel;
    @FXML private Label alamatLabel;
    @FXML private TextArea resepArea;
    @FXML private Label parafLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadResep();
    }

    private void loadResep() {
        int idRekamMedis = App.getSelectedRekamMedisId();
        String tanggal = App.getSelectedRekamMedisTanggal();
        int userId = App.getLoggedInUserId();
        
        if (idRekamMedis == 0 || userId <= 0) return;
        
        tanggalLabel.setText(tanggal);

        try (Connection conn = Database.getConnection()) {
            if (conn == null) return;

            // Dapatkan id_pasien dari userId
            int idPasien = 0;
            String sqlPasienId = "SELECT id_pasien FROM pasien WHERE id_user = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlPasienId)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idPasien = rs.getInt("id_pasien");
                    }
                }
            }

            if (idPasien == 0) return;

            // Dapatkan data resep
            String sql = "SELECT ro.obat, ro.aturan_pakai, p.nama_pasien, p.tanggal_lahir, p.alamat, d.nama_dokter "
                       + "FROM resep_obat ro "
                       + "JOIN pasien p ON ro.id_pasien = p.id_pasien "
                       + "JOIN dokter d ON ro.id_dokter = d.id_dokter "
                       + "WHERE ro.id_pasien = ? AND ro.tanggal = ?";
            
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idPasien);
                ps.setString(2, tanggal);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        namaDokterLabel.setText(rs.getString("nama_dokter"));
                        namaPasienLabel.setText(rs.getString("nama_pasien"));
                        tglLahirLabel.setText(rs.getString("tanggal_lahir"));
                        alamatLabel.setText(rs.getString("alamat"));
                        
                        String obat = rs.getString("obat");
                        String aturan = rs.getString("aturan_pakai");
                        
                        resepArea.setText("R/ \n" + obat + "\n\nS. " + aturan);
                        
                        // Set tanda tangan elektronik (paraf dokter)
                        parafLabel.setText("ttd.\n\n" + rs.getString("nama_dokter"));
                    } else {
                        resepArea.setText("Tidak ada data resep obat untuk tanggal ini.");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            resepArea.setText("Terjadi kesalahan saat memuat resep obat.");
        }
    }

    @FXML
    private void goBack() throws IOException {
        App.setRoot("RiwayatRekamMedisDetail");
    }
}
