package com.mycompany.projectklinik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.mycompany.projectklinik.App;
import javafx.animation.PauseTransition;
import javafx.fxml.Initializable;
import javafx.util.Duration;

public class SplashPasienController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(event -> {
            try {
                App.setRoot("WelcomePasien");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        delay.play();
    }
}
