package com.mycompany.projectklinik.model;

public class User {
    private int idUser;
    private String username;
    private int idRole;
    private String namaRole;

    public User(int idUser, String username, int idRole, String namaRole) {
        this.idUser = idUser;
        this.username = username;
        this.idRole = idRole;
        this.namaRole = namaRole;
    }

    public int getIdUser() {
        return idUser;
    }

    public String getUsername() {
        return username;
    }

    public int getIdRole() {
        return idRole;
    }

    public String getNamaRole() {
        return namaRole;
    }
}
